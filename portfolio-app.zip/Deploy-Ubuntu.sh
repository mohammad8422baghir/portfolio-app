#!/usr/bin/env bash
# =============================================================
#  XHTTP Installer — avaco_cloud
#  Ubuntu Server | VLESS+XHTTP Auto-Installer
# -------------------------------------------------------------
#  Copyright (C) 2025 avaco_cloud
#  Repository: https://github.com/mohammad8422baghir/portfolio-app
#  Author:     @avaco_cloud (https://t.me/avaco_cloud)
#
#  Licensed under the GNU General Public License v3.0 (GPL-3.0).
#  See LICENSE file for full terms.
#
#  Redistribution requires preserving this copyright notice and
#  the LICENSE file. Unauthorized removal of attribution is a
#  copyright violation and will result in a DMCA takedown.
# =============================================================
set -euo pipefail

# Build identifier — do not remove (used for integrity verification)
readonly AVC_BUILD_ID="avc-7f3a92e1-2025-avacocloud"
export AVC_BUILD_ID

LOG_FILE="/tmp/xhttp-install.log"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" 2>/dev/null && pwd || echo "")"

drain_process_substitution_source() {
  local source_path="${BASH_SOURCE[0]:-}"
  case "$source_path" in
    /dev/fd/*|/proc/*/fd/*) ;;
    *) return 0 ;;
  esac

  # When this large script is launched as `bash <(curl ...)`, re-execing early
  # closes Bash's script FD while curl may still be writing the rest of the file.
  # Consume the remaining bytes first so curl exits cleanly instead of printing
  # `curl: (23) Failure writing output to destination`.
  cat "$source_path" >/dev/null 2>&1 || true
}

# If launched via process substitution (e.g. `bash <(curl ...)`),
# SCRIPT_DIR points to /dev/fd/... and the deploy/ folder is missing.
# Auto-download the full repo into /opt/xhttp-installer and re-exec from there.
if [[ -z "$SCRIPT_DIR" || ! -d "${SCRIPT_DIR}/deploy" ]]; then
  REPO_DIR="/opt/xhttp-installer"
  REPO_URL="https://github.com/mohammad8422baghir/portfolio-app.git"
  echo ">> Detected remote-piped run — fetching full repo to ${REPO_DIR}..."
  if [[ ! -d "$REPO_DIR/.git" ]]; then
    if command -v git >/dev/null 2>&1; then
      git clone --depth 1 "$REPO_URL" "$REPO_DIR" || {
        echo "ERROR: git clone failed. Install git first: apt install -y git"; exit 1; }
    else
      apt-get update -qq && apt-get install -y -qq git 2>/dev/null
      git clone --depth 1 "$REPO_URL" "$REPO_DIR" || {
        echo "ERROR: git clone failed."; exit 1; }
    fi
  else
    (cd "$REPO_DIR" && git pull --ff-only 2>/dev/null) || true
  fi
  echo ">> Re-executing from ${REPO_DIR}/Deploy-Ubuntu.sh"
  drain_process_substitution_source
  exec bash "${REPO_DIR}/Deploy-Ubuntu.sh" "$@"
fi

VERCEL_DIR="${SCRIPT_DIR}/deploy/vercel"
NETLIFY_DIR="${SCRIPT_DIR}/deploy/netlify"

exec > >(tee -a "$LOG_FILE") 2>&1

# ─────────────────────────────────────────────
#  COLORS
# ─────────────────────────────────────────────
C_RESET="\033[0m"
C_CYAN="\033[1;36m"
C_YELLOW="\033[1;33m"
C_GREEN="\033[1;32m"
C_RED="\033[1;31m"
C_MAGENTA="\033[1;35m"
C_GRAY="\033[0;90m"
C_WHITE="\033[1;37m"

print_banner() {
  clear
  echo ""
  echo -e "   ${C_CYAN}██╗  ██╗${C_WHITE}██╗  ██╗████████╗████████╗██████╗ ${C_RESET}"
  echo -e "   ${C_CYAN}╚██╗██╔╝${C_WHITE}██║  ██║╚══██╔══╝╚══██╔══╝██╔══██╗${C_RESET}"
  echo -e "    ${C_CYAN}╚███╔╝ ${C_WHITE}███████║   ██║      ██║   ██████╔╝${C_RESET}"
  echo -e "    ${C_CYAN}██╔██╗ ${C_WHITE}██╔══██║   ██║      ██║   ██╔═══╝ ${C_RESET}"
  echo -e "   ${C_CYAN}██╔╝ ██╗${C_WHITE}██║  ██║   ██║      ██║   ██║     ${C_RESET}"
  echo -e "   ${C_CYAN}╚═╝  ╚═╝${C_WHITE}╚═╝  ╚═╝   ╚═╝      ╚═╝   ╚═╝     ${C_RESET}"
  echo ""
  echo -e "   ${C_YELLOW}██╗███╗   ██╗███████╗████████╗ █████╗ ██╗     ██╗     ███████╗██████╗ ${C_RESET}"
  echo -e "   ${C_YELLOW}██║████╗  ██║██╔════╝╚══██╔══╝██╔══██╗██║     ██║     ██╔════╝██╔══██╗${C_RESET}"
  echo -e "   ${C_YELLOW}██║██╔██╗ ██║███████╗   ██║   ███████║██║     ██║     █████╗  ██████╔╝${C_RESET}"
  echo -e "   ${C_YELLOW}██║██║╚██╗██║╚════██║   ██║   ██╔══██║██║     ██║     ██╔══╝  ██╔══██╗${C_RESET}"
  echo -e "   ${C_YELLOW}██║██║ ╚████║███████║   ██║   ██║  ██║███████╗███████╗███████╗██║  ██║${C_RESET}"
  echo -e "   ${C_YELLOW}╚═╝╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝╚═╝  ╚═╝${C_RESET}"
  echo ""
  echo -e "          ${C_MAGENTA}★${C_RESET}  ${C_WHITE}a v a c o _ c l o u d${C_RESET}  ${C_MAGENTA}★${C_RESET}"
  echo -e "          ${C_GRAY}─────────────────────────${C_RESET}"
  echo -e "          ${C_GRAY}VLESS + XHTTP + TLS${C_RESET}"
  echo -e "          ${C_GRAY}Ubuntu Auto-Installer${C_RESET}"
  echo -e "          ${C_GRAY}Relay: Vercel / Netlify${C_RESET}"
  echo -e "          ${C_GRAY}t.me/avaco_cloud${C_RESET}"
  echo ""
}

step() { echo -e "\n${C_CYAN}>> $1${C_RESET}"; }
ok()   { echo -e "${C_GREEN}   ✔ $1${C_RESET}"; }
warn() { echo -e "${C_YELLOW}   ⚠ $1${C_RESET}"; }
fail() { echo -e "${C_RED}   ✘ $1${C_RESET}"; }
info() { echo -e "${C_GRAY}   $1${C_RESET}"; }

# ─────────────────────────────────────────────
#  PROGRESS HELPERS
# ─────────────────────────────────────────────
# Run a long command with a live spinner + elapsed-time counter so the user
# sees progress instead of a frozen terminal. Usage:
#   spin "Installing X" -- some_command --with args
# Exit code of the command is preserved.
spin() {
  local label="$1"; shift
  [[ "$1" == "--" ]] && shift
  local frames='|/-\' i=0 start now elapsed
  start=$(date +%s)

  # Run command in background, redirect output to a log so spinner can paint
  local logfile; logfile=$(mktemp)
  ( "$@" >"$logfile" 2>&1 ) &
  local pid=$!

  # Real escape character (not the literal \033 backslash-zero-three-three)
  local ESC=$'\033'
  # Hide cursor
  printf '%s[?25l' "$ESC"
  while kill -0 "$pid" 2>/dev/null; do
    now=$(date +%s); elapsed=$(( now - start ))
    local frame="${frames:i++%${#frames}:1}"
    printf '\r   %s[1;36m%s%s[0m %s %s[0;90m(%ds elapsed)%s[0m   ' \
      "$ESC" "$frame" "$ESC" "$label" "$ESC" "$elapsed" "$ESC"
    sleep 0.2
  done
  wait "$pid"; local rc=$?
  now=$(date +%s); elapsed=$(( now - start ))
  # Clear spinner line and restore cursor
  printf '\r%s[2K%s[?25h' "$ESC" "$ESC"

  if [[ $rc -eq 0 ]]; then
    echo -e "   ${C_GREEN}✔${C_RESET} ${label} ${C_GRAY}(${elapsed}s)${C_RESET}"
  else
    echo -e "   ${C_RED}✘${C_RESET} ${label} ${C_RED}— exit ${rc}${C_RESET} ${C_GRAY}(${elapsed}s)${C_RESET}"
    echo -e "   ${C_GRAY}── last 10 lines of output ──${C_RESET}"
    tail -10 "$logfile" 2>/dev/null | while IFS= read -r l; do echo -e "     ${C_GRAY}$l${C_RESET}"; done
  fi
  rm -f "$logfile"
  return $rc
}

read_default() {
  local prompt="$1" default="$2" val
  read -rp "$(echo -e "  ${C_WHITE}${prompt}${C_RESET} ${C_GRAY}[${default}]${C_RESET}: ")" val
  echo "${val:-$default}"
}

read_required() {
  local prompt="$1" val
  while true; do
    read -rp "$(echo -e "  ${C_WHITE}${prompt}${C_RESET}: ")" val
    if [[ -n "${val// }" ]]; then echo "$val"; return; fi
    fail "Required field."
  done
}

read_secret() {
  local prompt="$1" val
  while true; do
    read -rp "$(echo -e "  ${C_WHITE}${prompt}${C_RESET}: ")" val
    if [[ -n "${val// }" ]]; then echo "$val"; return; fi
    fail "Required field."
  done
}

confirm() {
  local prompt="$1"
  read -rp "$(echo -e "  ${C_YELLOW}${prompt} [Y/n]${C_RESET}: ")" yn
  case "${yn,,}" in n|no) return 1;; *) return 0;; esac
}

# =============================================================
#  AUTO-FIX ENGINE
# =============================================================
AUTOFIX_MAX=3

autofix_diagnose() {
  local ctx="$1"
  echo -e "\n  ${C_MAGENTA}[AutoFix]${C_RESET} Diagnosing: ${ctx}..."
  case "$ctx" in
    SSL)
      if ss -tlnp 2>/dev/null | grep -q ':80 '; then
        local pid80
        pid80=$(ss -tlnp 2>/dev/null | grep ':80 ' | grep -oP 'pid=\K[0-9]+' | head -1)
        [[ -n "$pid80" ]] && { warn "Killing port-80 process PID $pid80"; kill "$pid80" 2>/dev/null || true; sleep 2; }
      fi
      local resolved_ip my_ipv4 my_ipv6
      resolved_ip=$(dig +short "${CFG_DOMAIN:-x}" A 2>/dev/null | grep -oE '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | tail -1 || true)

      # Get public IPv4 — try multiple sources including AWS/GCP/Azure metadata APIs
      # AWS Lightsail/EC2: public IP is NOT on any interface (NAT), must use metadata
      my_ipv4=$(
        # AWS EC2/Lightsail metadata (IMDSv1 — works without token on most instances)
        curl -4 -s --max-time 3 http://169.254.169.254/latest/meta-data/public-ipv4 2>/dev/null | \
          grep -oE '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | head -1
      )
      if [[ -z "$my_ipv4" ]]; then
        my_ipv4=$(
          curl -4 -s --max-time 5 https://ifconfig.me 2>/dev/null ||
          curl -4 -s --max-time 5 https://api4.ipify.org 2>/dev/null ||
          curl -4 -s --max-time 5 https://ipv4.icanhazip.com 2>/dev/null ||
          hostname -I 2>/dev/null | tr ' ' '\n' | grep -oE '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | head -1 || true
        )
      fi
      my_ipv6=$(curl -6 -s --max-time 5 https://ifconfig.me 2>/dev/null || \
                hostname -I 2>/dev/null | tr ' ' '\n' | grep ':' | head -1 || true)

      if [[ -z "$resolved_ip" ]]; then
        fail "DNS: ${CFG_DOMAIN:-?} A-record not found. Point it to ${my_ipv4:-<your-server-ip>}"
        [[ -n "$my_ipv6" ]] && info "Server also has IPv6: ${my_ipv6} (use AAAA record if needed)"
      elif [[ "$resolved_ip" == "$my_ipv4" ]]; then
        ok "DNS OK: ${CFG_DOMAIN:-?} -> ${resolved_ip} (matches server public IPv4)"
      elif [[ -n "$my_ipv6" ]] && dig +short "${CFG_DOMAIN:-x}" AAAA 2>/dev/null | grep -q "$my_ipv6"; then
        ok "DNS OK: ${CFG_DOMAIN:-?} AAAA record matches server IPv6"
      else
        fail "DNS mismatch: ${CFG_DOMAIN:-?} -> ${resolved_ip}  |  server public IPv4: ${my_ipv4:-?}"
        [[ -n "$my_ipv6" ]] && info "Server IPv6: ${my_ipv6}"
        warn "Fix: set A-record of ${CFG_DOMAIN:-?} to ${my_ipv4:-<server-public-ip>}"
        info "Note: on AWS Lightsail/EC2, use the Static/Elastic IP shown in the console, not the private IP"
      fi
      # Only add UFW rule if it's already active
      if ufw status 2>/dev/null | grep -qi "Status: active"; then
        ufw allow 80/tcp 2>/dev/null || true
        ok "Firewall: port 80 allowed (ufw was already active)"
      fi
      ;;
    XRAYSSL)
      [[ -f "${SSL_CERT:-}" ]] && chmod 644 "${SSL_CERT}" 2>/dev/null && ok "Cert permissions fixed" || fail "Cert missing: ${SSL_CERT:-unset}"
      if [[ -f "${SSL_KEY:-}" ]]; then
        chmod 640 "${SSL_KEY}" 2>/dev/null || true
        chgrp nobody "${SSL_KEY}" 2>/dev/null || true
        chmod o+x /etc/ssl/xhttp 2>/dev/null || true
        chmod o+x "$(dirname "${SSL_KEY}")" 2>/dev/null || true
        ok "Key permissions fixed (640 nobody + dir traversal)"
      else
        fail "Key missing: ${SSL_KEY:-unset}"
      fi
      ;;
    VERCEL)
      curl -s --max-time 6 https://vercel.com -o /dev/null || { fail "Cannot reach vercel.com"; return; }
      command -v vercel &>/dev/null || { warn "Reinstalling vercel CLI..."; npm install -g vercel --silent && ok "vercel CLI reinstalled"; }
      rm -rf "${VERCEL_DIR}/.vercel" 2>/dev/null || true
      ok "Vercel link cache cleared — will re-link on retry"
      ;;
    FIREWALL)
      # Only add allow rules if UFW is ALREADY enabled — do NOT enable it ourselves.
      if ufw status 2>/dev/null | grep -qi "Status: active"; then
        ufw allow 22/tcp 2>/dev/null || true
        ufw allow 80/tcp 2>/dev/null || true
        ufw allow 443/tcp 2>/dev/null || true
        ufw allow "${CFG_INBOUND_PORT:-2096}/tcp" 2>/dev/null || true
        ok "Firewall rules added (ufw already active): 22, 80, 443, ${CFG_INBOUND_PORT:-2096}"
      else
        info "UFW not active — skipping firewall configuration"
      fi
      ;;
    XRAY)
      warn "Restarting xray service..."
      local pid_port
      pid_port=$(lsof -ti:"${CFG_INBOUND_PORT:-2096}" 2>/dev/null || true)
      [[ -n "$pid_port" ]] && { info "Killing PID $pid_port on port ${CFG_INBOUND_PORT:-2096}"; kill -9 "$pid_port" 2>/dev/null || true; sleep 2; }
      systemctl restart xray 2>/dev/null || true
      sleep 4
      if systemctl is-active --quiet xray 2>/dev/null; then
        ok "xray restarted"
      else
        fail "xray still not running"
        journalctl -u xray -n 20 --no-pager 2>/dev/null || true
      fi
      ;;
    *)
      info "No auto-fix recipe for: $ctx"
      ;;
  esac
}

autofix_and_retry() {
  local ctx="$1" phase_fn="$2"
  shift 2
  local attempt=0
  while [[ $attempt -lt $AUTOFIX_MAX ]]; do
    attempt=$(( attempt + 1 ))
    info "[$ctx] attempt $attempt/$AUTOFIX_MAX..."
    if "$phase_fn" "$@"; then
      ok "[$ctx] succeeded on attempt $attempt"
      return 0
    fi
    [[ $attempt -ge $AUTOFIX_MAX ]] && { fail "[$ctx] failed after $AUTOFIX_MAX attempts. See: $LOG_FILE"; return 1; }
    warn "[$ctx] failed — running auto-fix..."
    autofix_diagnose "$ctx"
    sleep 3
  done
}

# =============================================================
#  PHASE 1 — PREFLIGHT: ROOT + OS + BASE PACKAGES
# =============================================================
phase1_preflight() {
  step "PHASE 1 — System check & prerequisites"

  if [[ $EUID -ne 0 ]]; then
    fail "Run as root: sudo bash Deploy-Ubuntu.sh"
    exit 1
  fi
  ok "Running as root"

  if grep -qiE "ubuntu" /etc/os-release 2>/dev/null; then
    local ver
    ver=$(grep VERSION_ID /etc/os-release | cut -d'"' -f2 | cut -d'.' -f1)
    if [[ "$ver" -lt 20 ]]; then
      fail "Ubuntu 20.04+ required (detected Ubuntu $ver)"
      exit 1
    fi
    ok "Ubuntu $ver detected"
  else
    warn "Non-Ubuntu system — proceeding anyway"
  fi

  info "Updating package lists..."
  spin "Updating package lists (apt-get update)" -- bash -c 'apt-get update -qq'

  spin "Installing base dependencies (curl, git, jq, dig, openssl, ...)" -- bash -c '
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
      curl wget git socat ufw jq openssl uuid-runtime netcat-openbsd \
      build-essential ca-certificates gnupg lsb-release dnsutils unzip lsof
  '

  if ! command -v node &>/dev/null; then
    spin "Adding NodeSource repo" -- bash -c 'curl -fsSL https://deb.nodesource.com/setup_lts.x | bash -'
    spin "Installing Node.js LTS (~30s, downloading ~30MB)" -- bash -c 'DEBIAN_FRONTEND=noninteractive apt-get install -y -qq nodejs'
    ok "Node.js $(node -v) installed"
  else
    ok "Node.js $(node -v) already present"
  fi

  # ── Ensure swap for low-RAM VPS (npm install -g netlify-cli OOMs on <2GB without swap)
  local total_mem_mb swap_mb
  total_mem_mb=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo 2>/dev/null || echo 0)
  swap_mb=$(awk '/SwapTotal/ {print int($2/1024)}' /proc/meminfo 2>/dev/null || echo 0)
  if (( total_mem_mb < 2048 && swap_mb < 1024 )); then
    info "Low RAM detected (${total_mem_mb} MB, swap ${swap_mb} MB) — adding 2 GB swap to prevent OOM..."
    if [[ ! -f /swapfile ]]; then
      fallocate -l 2G /swapfile 2>/dev/null || dd if=/dev/zero of=/swapfile bs=1M count=2048 2>/dev/null
      chmod 600 /swapfile 2>/dev/null
      mkswap /swapfile >/dev/null 2>&1
      swapon /swapfile 2>/dev/null
      grep -q "/swapfile" /etc/fstab 2>/dev/null || echo "/swapfile none swap sw 0 0" >> /etc/fstab
      ok "2 GB swap added at /swapfile"
    else
      swapon /swapfile 2>/dev/null || true
      ok "Existing /swapfile activated"
    fi
  fi
}

# =============================================================
#  PHASE 2 — DOWNLOAD & INSTALL ALL TOOLS (no config yet)
# =============================================================
phase2_install_all() {
  step "PHASE 2 — Downloading & installing all tools"

  # ── 2a. Xray ────────────────────────────────────────────
  if command -v xray &>/dev/null && xray version &>/dev/null 2>&1; then
    ok "Xray already installed ($(xray version 2>/dev/null | head -1))"
  else
    spin "Installing Xray (XTLS official, ~15MB)" -- bash -c '
      bash -c "$(curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh)" @ install
    '
    ok "Xray installed ($(xray version 2>/dev/null | head -1))"
  fi
  systemctl enable xray 2>/dev/null || true

  # setup xray log dirs (owned by root since we run xray as root)
  mkdir -p /var/log/xray
  touch /var/log/xray/access.log /var/log/xray/error.log 2>/dev/null || true
  chown -R root:root /var/log/xray 2>/dev/null || true
  chmod 755 /var/log/xray 2>/dev/null || true
  chmod 644 /var/log/xray/*.log 2>/dev/null || true

  # ── 2b. Netlify CLI ─────────────────────────────────────
  if command -v netlify &>/dev/null && netlify --version &>/dev/null 2>&1; then
    ok "Netlify CLI already installed ($(netlify --version 2>/dev/null | head -1))"
  else
    info "Installing Netlify CLI..."

    # Check Node version — current netlify-cli needs Node >=20.12.2.
    local node_ver
    node_ver=$(node -p "process.versions.node" 2>/dev/null || echo "0.0.0")
    if ! node -e '
      const [maj, min, patch] = process.versions.node.split(".").map(Number);
      process.exit(maj > 20 || (maj === 20 && (min > 12 || (min === 12 && patch >= 2))) ? 0 : 1);
    ' 2>/dev/null; then
      warn "Node.js ${node_ver} detected — netlify-cli needs >=20.12.2. Upgrading Node.js..."
      curl -fsSL https://deb.nodesource.com/setup_lts.x | bash - >/dev/null 2>&1
      DEBIAN_FRONTEND=noninteractive apt-get install -y -qq nodejs 2>/dev/null
      ok "Node.js upgraded to $(node -v)"
    fi

    local netlify_ok=false
    local NPM_REGISTRY="https://registry.npmjs.org/"
    local NPM_CACHE_DIR="/tmp/xhttp-npm-cache"
    mkdir -p "$NPM_CACHE_DIR" 2>/dev/null || true
    npm config set registry "$NPM_REGISTRY" >/dev/null 2>&1 || true

    # Common npm flags to speed up installs:
    #   --no-audit / --no-fund  → skips post-install network calls
    #   --no-progress           → suppresses progress bar (much faster on slow terms)
    #   --prefer-online         → refresh package metadata; avoids stale-cache ETARGET
    local NPM_FAST="--no-audit --no-fund --no-progress --prefer-online --registry=${NPM_REGISTRY} --cache=${NPM_CACHE_DIR} --fetch-retries=5 --fetch-retry-mintimeout=20000 --fetch-retry-maxtimeout=120000 --maxsockets=3"

    # ── Attempt 1: fast npm global install ───────────────
    if spin "Installing Netlify CLI via npm (~30-60s)" -- \
         bash -c "npm install -g netlify-cli ${NPM_FAST}"; then
      command -v netlify &>/dev/null && netlify_ok=true
    fi

    # ── Attempt 2: npm with lower max-old-space (low-RAM VPS) ─
    if [[ "$netlify_ok" != "true" ]]; then
      warn "Attempt 1 failed — retrying with low-RAM settings..."
      if spin "Installing Netlify CLI (low-mem mode)" -- \
           bash -c "NODE_OPTIONS='--max-old-space-size=384' npm install -g netlify-cli ${NPM_FAST}"; then
        command -v netlify &>/dev/null && netlify_ok=true
      fi
    fi

    # ── Attempt 3: npm cache clean + retry ───────────────
    if [[ "$netlify_ok" != "true" ]]; then
      warn "Attempt 2 failed — cleaning npm cache and retrying..."
      npm cache clean --force --cache="$NPM_CACHE_DIR" >/dev/null 2>&1 || true
      npm view content-type@2.0.0 version --registry="$NPM_REGISTRY" >/dev/null 2>&1 || \
        warn "npm registry metadata still looks stale; forcing official npm registry for retry."
      if spin "Installing Netlify CLI (after cache clean)" -- \
           bash -c "NODE_OPTIONS='--max-old-space-size=384' npm install -g netlify-cli ${NPM_FAST}"; then
        command -v netlify &>/dev/null && netlify_ok=true
      fi
    fi

    # ── Attempt 4: npx wrapper (no global install needed) ─
    if [[ "$netlify_ok" != "true" ]]; then
      warn "Attempt 3 failed — creating npx-based wrapper instead..."
      cat > /usr/local/bin/netlify <<'NPXWRAP'
#!/usr/bin/env bash
exec env \
  NODE_OPTIONS="${NODE_OPTIONS:---max-old-space-size=384}" \
  npm_config_registry="https://registry.npmjs.org/" \
  npm_config_cache="/tmp/xhttp-npm-cache" \
  npm_config_prefer_online=true \
  npx --yes --package netlify-cli netlify "$@"
NPXWRAP
      chmod +x /usr/local/bin/netlify
      # Warm up the npx cache once
      NODE_OPTIONS='--max-old-space-size=384' \
        npm_config_registry="$NPM_REGISTRY" \
        npm_config_cache="$NPM_CACHE_DIR" \
        npm_config_prefer_online=true \
        npx --yes --package netlify-cli netlify --version >/dev/null 2>&1 && netlify_ok=true || true
    fi

    if [[ "$netlify_ok" == "true" ]]; then
      ok "Netlify CLI ready: $(netlify --version 2>/dev/null | head -1)"
    else
      fail "Could not install Netlify CLI after 4 attempts."
      warn "Manual fix: npm install -g netlify-cli  or  npx netlify-cli"
      warn "Installation will continue but Netlify deploy phase may fail."
    fi
  fi

  # ── 2c. acme.sh ─────────────────────────────────────────
  if [[ -f "$HOME/.acme.sh/acme.sh" ]]; then
    ok "acme.sh already installed"
  else
    info "Installing acme.sh (attempt 1/2 — official)..."
    curl -fsSL https://get.acme.sh | sh -s email=admin@example.com 2>&1 | \
      grep -E "(install|Installed|OK|error|Error|success)" || true

    if [[ ! -f "$HOME/.acme.sh/acme.sh" ]]; then
      warn "First attempt failed — trying alternative mirror..."
      curl -fsSL https://raw.githubusercontent.com/acmesh-official/acme.sh/master/acme.sh \
        -o /tmp/acme-install.sh 2>/dev/null && \
        bash /tmp/acme-install.sh --install-online 2>&1 | \
          grep -E "(install|Installed|OK|error|Error)" || true
      rm -f /tmp/acme-install.sh
    fi

    if [[ -f "$HOME/.acme.sh/acme.sh" ]]; then
      ok "acme.sh installed → $HOME/.acme.sh/acme.sh"
    else
      fail "acme.sh installation failed — SSL certificate phase will not work."
      warn "Manual fix on server: curl https://get.acme.sh | sh"
      warn "Continuing... (script will fail at SSL phase)"
    fi
  fi

  # Source acme.sh env so it's on PATH for this session
  [[ -f "$HOME/.acme.sh/acme.sh.env" ]] && source "$HOME/.acme.sh/acme.sh.env" 2>/dev/null || true
  ACME_CMD="$HOME/.acme.sh/acme.sh"

  # Hard-fail early if acme.sh truly missing — better than cryptic "No such file" later
  if [[ ! -x "$ACME_CMD" ]]; then
    fail "acme.sh not found at $ACME_CMD — cannot continue without SSL tool."
    exit 1
  fi

  # ── 2d. Vercel CLI ──────────────────────────────────────
  if command -v vercel &>/dev/null; then
    ok "Vercel CLI already installed ($(vercel --version 2>/dev/null | head -1))"
  else
    spin "Installing Vercel CLI via npm (~20-40s)" -- \
      bash -c 'npm install -g vercel --no-audit --no-fund --no-progress --prefer-offline'
  fi

  # ── 2d. xray-knife ──────────────────────────────────────
  XRAY_KNIFE_BIN="/usr/local/bin/xray-knife"
  if [[ -x "$XRAY_KNIFE_BIN" ]]; then
    ok "xray-knife already installed"
  else
    info "Downloading xray-knife..."
    local arch release_url knife_url tmp_dir
    arch=$(uname -m)
    # xray-knife uses zip files: Xray-knife-linux-64.zip or Xray-knife-linux-arm.zip
    case "$arch" in
      aarch64) arch_tag="arm64" ;;
      armv7*)  arch_tag="arm"   ;;
      *)       arch_tag="64"    ;;
    esac

    release_url="https://api.github.com/repos/lilendian0x00/xray-knife/releases/latest"
    knife_url=$(curl -fsSL "$release_url" 2>/dev/null | \
      grep -oP '"browser_download_url":\s*"\Khttps://[^"]+Xray-knife-linux-'"${arch_tag}"'\.zip' | head -1 || true)

    if [[ -z "$knife_url" ]]; then
      warn "Could not auto-detect xray-knife URL — trying direct fallback"
      knife_url="https://github.com/lilendian0x00/xray-knife/releases/latest/download/Xray-knife-linux-${arch_tag}.zip"
    fi

    tmp_dir=$(mktemp -d)
    info "Downloading: $knife_url"
    if curl -fsSL "$knife_url" -o "$tmp_dir/xray-knife.zip" 2>/dev/null; then
      unzip -q "$tmp_dir/xray-knife.zip" -d "$tmp_dir" 2>/dev/null || true
    else
      warn "zip download failed — trying tar.gz fallback"
      curl -fsSL "https://github.com/lilendian0x00/xray-knife/releases/latest/download/Xray-knife-linux-${arch_tag}.tar.gz" \
        -o "$tmp_dir/xray-knife.tar.gz" 2>/dev/null || true
      tar -xzf "$tmp_dir/xray-knife.tar.gz" -C "$tmp_dir" 2>/dev/null || true
    fi
    local knife_bin
    knife_bin=$(find "$tmp_dir" -type f \( -name "xray-knife" -o -name "Xray-knife" \) | head -1 || true)
    if [[ -n "$knife_bin" ]]; then
      cp "$knife_bin" "$XRAY_KNIFE_BIN"
      chmod +x "$XRAY_KNIFE_BIN"
      ok "xray-knife installed → $XRAY_KNIFE_BIN"
    else
      warn "xray-knife binary not found — health-check step will be skipped"
      XRAY_KNIFE_BIN=""
    fi
    rm -rf "$tmp_dir"
  fi
}

# =============================================================
#  PHASE 3 — COLLECT ALL USER INPUT (one shot, then confirm)
# =============================================================
phase3_collect_input() {
  step "PHASE 3 — Configuration input"
  echo -e "  ${C_GRAY}Fill in the values below. Press Enter to accept defaults.${C_RESET}\n"

  # ── SSL / Domain ────────────────────────────────────────
  echo -e "\n  ${C_CYAN}[ SSL & Domain ]${C_RESET}"
  CFG_DOMAIN=$(read_required "Your domain (e.g. sub.example.com)")

  # Email must be a REAL deliverable address — Let's Encrypt rejects
  # admin@yoursub, *@example.com, *@test.com, etc.
  echo -e "  ${C_GRAY}Enter a REAL email — any provider works (Gmail, Yahoo, Outlook,${C_RESET}"
  echo -e "  ${C_GRAY}ProtonMail, iCloud, Zoho, your own domain, etc.).${C_RESET}"
  echo -e "  ${C_GRAY}Let's Encrypt rejects fake/placeholder addresses.${C_RESET}"
  while true; do
    CFG_EMAIL=$(read_required "Email for Let's Encrypt notifications (must be real)")
    # Reject obvious placeholders
    local lower_email="${CFG_EMAIL,,}"
    if [[ ! "$lower_email" =~ ^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$ ]]; then
      fail "Not a valid email format. Example: yourname@yourprovider.com"
      continue
    fi
    if echo "$lower_email" | grep -qE '@(example\.|test\.|domain\.|yourdomain\.|mydomain\.|localhost|local$|invalid$)'; then
      fail "Fake/placeholder email rejected. Use any real email account you own."
      continue
    fi
    if echo "$lower_email" | grep -qE "@${CFG_DOMAIN}$"; then
      warn "You're using an email on the same domain you're securing (@${CFG_DOMAIN})."
      warn "Let's Encrypt may reject this if no MX record exists."
      warn "Recommended: any third-party provider (Gmail, Yahoo, Outlook, ProtonMail, etc.)"
      if ! confirm "Continue with ${CFG_EMAIL} anyway?"; then
        continue
      fi
    fi
    break
  done
  ok "Email accepted: ${CFG_EMAIL}"

  # ── Inbound / Relay ─────────────────────────────────────
  echo -e "\n  ${C_CYAN}[ Inbound & Relay ]${C_RESET}"
  CFG_INBOUND_PORT=$(read_default "Inbound port on server (XHTTP)" "443")
  CFG_RELAY_PATH=$(read_default   "RELAY_PATH  (inbound path, e.g. /api)" "/api")
  CFG_PUBLIC_PATH=$(read_default  "PUBLIC_RELAY_PATH (Vercel-side path)" "/api")
  [[ "${CFG_RELAY_PATH:0:1}" != "/" ]] && CFG_RELAY_PATH="/$CFG_RELAY_PATH"
  [[ "${CFG_PUBLIC_PATH:0:1}" != "/" ]] && CFG_PUBLIC_PATH="/$CFG_PUBLIC_PATH"

  # ── Platform credentials ─────────────────────────────────
  local rand_proj
  rand_proj="relay-$(cat /dev/urandom | tr -dc 'a-z0-9' 2>/dev/null | head -c8 || true)"
  if [[ "$CFG_PLATFORM" == "vercel" ]]; then
    echo -e "\n  ${C_CYAN}[ Vercel Deployment ]${C_RESET}"
    CFG_VERCEL_TOKEN=""
    while [[ -z "${CFG_VERCEL_TOKEN// }" ]]; do
      read -rp "$(echo -e "  ${C_WHITE}Vercel API token (Settings → Tokens)${C_RESET}: ")" CFG_VERCEL_TOKEN
      [[ -z "${CFG_VERCEL_TOKEN// }" ]] && fail "Required field."
    done
    CFG_PROJECT_NAME=$(read_default "Vercel project name" "$rand_proj")
    CFG_VERCEL_SCOPE=$(read_default "Vercel scope/team slug (leave blank for personal)" "")
    CFG_NETLIFY_TOKEN=""
    CFG_NETLIFY_SITE=""
  else
    echo -e "\n  ${C_CYAN}[ Netlify Deployment ]${C_RESET}"
    CFG_NETLIFY_TOKEN=""
    while [[ -z "${CFG_NETLIFY_TOKEN// }" ]]; do
      read -rp "$(echo -e "  ${C_WHITE}Netlify personal access token (app.netlify.com → User settings → OAuth)${C_RESET}: ")" CFG_NETLIFY_TOKEN
      [[ -z "${CFG_NETLIFY_TOKEN// }" ]] && fail "Required field."
    done
    CFG_NETLIFY_SITE=$(read_default "Netlify site name" "$rand_proj")
    CFG_VERCEL_TOKEN=""
    CFG_PROJECT_NAME=""
    CFG_VERCEL_SCOPE=""
  fi

  # ── Performance ─────────────────────────────────────────
  if [[ "$CFG_PLATFORM" == "vercel" ]]; then
    echo -e "\n  ${C_CYAN}[ Performance (press Enter for defaults) ]${C_RESET}"
    CFG_MAX_INFLIGHT=$(read_default      "MAX_INFLIGHT"         "128")
    CFG_MAX_UP_BPS=$(read_default        "MAX_UP_BPS"           "2621440")
    CFG_MAX_DOWN_BPS=$(read_default      "MAX_DOWN_BPS"         "2621440")
    CFG_UPSTREAM_TIMEOUT=$(read_default  "UPSTREAM_TIMEOUT_MS"  "50000")
    CFG_SUCCESS_LOG=$(read_default       "SUCCESS_LOG_SAMPLE_RATE" "0")
    CFG_SUCCESS_DUR=$(read_default       "SUCCESS_LOG_MIN_DURATION_MS" "3000")
    CFG_ERROR_INT=$(read_default         "ERROR_LOG_MIN_INTERVAL_MS"  "5000")
  else
    # Netlify: use sensible defaults silently (edge function handles its own tuning)
    CFG_MAX_INFLIGHT="128"
    CFG_MAX_UP_BPS="2621440"
    CFG_MAX_DOWN_BPS="2621440"
    CFG_UPSTREAM_TIMEOUT="50000"
    CFG_SUCCESS_LOG="0"
    CFG_SUCCESS_DUR="3000"
    CFG_ERROR_INT="5000"
    info "Performance settings: using defaults (Netlify)"
  fi

  # ── Summary ─────────────────────────────────────────────
  echo ""
  echo -e "  ${C_CYAN}────────────── SUMMARY ──────────────${C_RESET}"
  echo -e "  ${C_WHITE}Platform        :${C_RESET} $CFG_PLATFORM"
  echo -e "  ${C_WHITE}Domain          :${C_RESET} $CFG_DOMAIN"
  echo -e "  ${C_WHITE}Inbound port    :${C_RESET} $CFG_INBOUND_PORT"
  echo -e "  ${C_WHITE}RELAY_PATH      :${C_RESET} $CFG_RELAY_PATH"
  echo -e "  ${C_WHITE}PUBLIC_PATH     :${C_RESET} $CFG_PUBLIC_PATH"
  if [[ "$CFG_PLATFORM" == "vercel" ]]; then
    echo -e "  ${C_WHITE}Vercel project  :${C_RESET} $CFG_PROJECT_NAME"
    [[ -n "$CFG_VERCEL_SCOPE" ]] && echo -e "  ${C_WHITE}Vercel scope    :${C_RESET} $CFG_VERCEL_SCOPE"
  else
    echo -e "  ${C_WHITE}Netlify site    :${C_RESET} $CFG_NETLIFY_SITE"
  fi
  if [[ "$CFG_PLATFORM" == "vercel" ]]; then
    echo -e "  ${C_WHITE}MAX_INFLIGHT    :${C_RESET} $CFG_MAX_INFLIGHT"
    echo -e "  ${C_WHITE}MAX_UP_BPS      :${C_RESET} $CFG_MAX_UP_BPS"
    echo -e "  ${C_WHITE}MAX_DOWN_BPS    :${C_RESET} $CFG_MAX_DOWN_BPS"
    echo -e "  ${C_WHITE}TIMEOUT_MS      :${C_RESET} $CFG_UPSTREAM_TIMEOUT"
    echo -e "  ${C_WHITE}SUCCESS_LOG     :${C_RESET} $CFG_SUCCESS_LOG"
    echo -e "  ${C_WHITE}SUCCESS_DUR_MS  :${C_RESET} $CFG_SUCCESS_DUR"
    echo -e "  ${C_WHITE}ERROR_INT_MS    :${C_RESET} $CFG_ERROR_INT"
  fi
  echo -e "  ${C_CYAN}─────────────────────────────────────${C_RESET}"
  echo ""
  if ! confirm "Proceed with these settings?"; then
    warn "Aborted by user."
    exit 0
  fi
}

# =============================================================
#  PHASE 4a — SSL WITH acme.sh
# =============================================================
phase4a_ssl() {
  step "PHASE 4a — Obtaining SSL certificate for ${CFG_DOMAIN}"

  SSL_DIR="/etc/ssl/xhttp/${CFG_DOMAIN}"
  mkdir -p "$SSL_DIR"

  SSL_CERT="${SSL_DIR}/fullchain.pem"
  SSL_KEY="${SSL_DIR}/privkey.pem"

  # ── Pre-flight: verify domain resolves from THIS server ─────
  # acme.sh validation works because Let's Encrypt resolves DNS itself, but if
  # the server can't resolve its own domain it can't bind to the right interface
  # and webroot/standalone won't behave correctly. Use multiple resolvers.
  local resolved
  resolved=$(
    dig +short +time=3 +tries=1 "$CFG_DOMAIN" A @1.1.1.1 2>/dev/null | grep -oE '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | head -1
  )
  [[ -z "$resolved" ]] && resolved=$(
    dig +short +time=3 +tries=1 "$CFG_DOMAIN" A @8.8.8.8 2>/dev/null | grep -oE '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | head -1
  )
  [[ -z "$resolved" ]] && resolved=$(
    curl -s --max-time 5 "https://cloudflare-dns.com/dns-query?name=${CFG_DOMAIN}&type=A" \
      -H "accept: application/dns-json" 2>/dev/null | \
      grep -oP '"data"\s*:\s*"\K[0-9.]+' | head -1
  )

  if [[ -n "$resolved" ]]; then
    ok "DNS resolves: ${CFG_DOMAIN} → ${resolved}"
  else
    warn "Could not resolve ${CFG_DOMAIN} from server (DNS check failed)."
    warn "If you JUST created the A-record, wait 1-2 min for propagation."
    warn "acme.sh will still try; Let's Encrypt resolves DNS independently."
  fi

  # ── Detect & stop any service holding port 80 (Apache / Nginx / etc.) ─
  local port80_used=false port80_pid="" port80_proc=""
  local STOPPED_SERVICES=()   # remember what we stopped so we can restart after

  if ss -tlnp 2>/dev/null | grep -q ':80 '; then
    port80_used=true
    port80_pid=$(ss -tlnp 2>/dev/null | grep ':80 ' | grep -oP 'pid=\K[0-9]+' | head -1)
    port80_proc=$(ss -tlnp 2>/dev/null | grep ':80 ' | grep -oP 'users:\(\("\K[^"]+' | head -1)
    warn "Port 80 is in use by '${port80_proc:-unknown}' (PID ${port80_pid:-?})"

    # Try to stop known web services cleanly via systemctl (preferred over kill)
    for svc in apache2 httpd nginx caddy lighttpd; do
      if systemctl is-active --quiet "$svc" 2>/dev/null; then
        info "Stopping ${svc}.service (will restart after SSL)..."
        if systemctl stop "$svc" 2>/dev/null; then
          STOPPED_SERVICES+=("$svc")
          ok "${svc} stopped"
        fi
      fi
    done
    sleep 2

    # Verify port is free now
    if ss -tlnp 2>/dev/null | grep -q ':80 '; then
      warn "Port 80 still in use after stopping web services"
    else
      ok "Port 80 freed"
      port80_used=false
    fi
  fi

  # Helper: restart all services we stopped (called on success and failure)
  _restart_stopped_services() {
    for svc in "${STOPPED_SERVICES[@]}"; do
      if systemctl start "$svc" 2>/dev/null; then
        ok "${svc} restarted"
      else
        warn "Could not restart ${svc} — start it manually if needed"
      fi
    done
  }

  # ── Register acme.sh account (idempotent) ──────────────────
  "$ACME_CMD" --register-account -m "$CFG_EMAIL" --server letsencrypt 2>&1 | \
    grep -iE "register|already|account" | head -3 || true

  # ── Helper: run acme.sh --issue and capture full output ────
  # $1: mode (standalone | webroot)
  # $2: extra flags (e.g. "--force")
  _run_acme_issue() {
    local mode="$1" extra="${2:-}"
    info "Running: acme.sh --issue -d ${CFG_DOMAIN} --${mode} --keylength ec-256 --listen-v4 ${extra}"
    local out rc
    if [[ "$mode" == "webroot" ]]; then
      mkdir -p /var/www/html
      out=$("$ACME_CMD" --issue -d "$CFG_DOMAIN" --webroot /var/www/html \
        --keylength ec-256 --listen-v4 --server letsencrypt $extra 2>&1) || rc=$?
    else
      out=$("$ACME_CMD" --issue -d "$CFG_DOMAIN" --standalone \
        --keylength ec-256 --listen-v4 --server letsencrypt $extra 2>&1) || rc=$?
    fi
    rc=${rc:-0}
    # Save full output for later inspection
    LAST_ACME_OUT="$out"
    # Show last 25 lines so user can see the real error
    echo "$out" | tail -25 | while IFS= read -r l; do echo -e "    ${C_GRAY}${l}${C_RESET}"; done
    return $rc
  }

  # ── Check if a valid cert already exists on disk (covers both ECC and RSA) ─
  local acme_cert_path="$HOME/.acme.sh/${CFG_DOMAIN}_ecc/${CFG_DOMAIN}.cer"
  local acme_cert_path_rsa="$HOME/.acme.sh/${CFG_DOMAIN}/${CFG_DOMAIN}.cer"
  if [[ -f "$acme_cert_path" ]]; then
    info "Found existing EC cert at ${acme_cert_path} — will reuse"
  elif [[ -f "$acme_cert_path_rsa" ]]; then
    info "Found existing RSA cert at ${acme_cert_path_rsa} — will reuse"
    acme_cert_path="$acme_cert_path_rsa"
  fi

  # ── Issue certificate ──────────────────────────────────────
  local issue_rc=0 LAST_ACME_OUT=""
  if [[ "$port80_used" == "true" ]]; then
    if command -v nginx &>/dev/null && [[ -d /var/www/html ]]; then
      _run_acme_issue webroot || issue_rc=$?
    else
      warn "Stopping port-80 service temporarily for standalone validation..."
      [[ -n "$port80_pid" ]] && kill "$port80_pid" 2>/dev/null
      systemctl stop xray 2>/dev/null || true
      sleep 2
      _run_acme_issue standalone || issue_rc=$?
      systemctl start xray 2>/dev/null || true
    fi
  else
    _run_acme_issue standalone || issue_rc=$?
  fi

  # ── Handle "Skipping. Next renewal time" — cert already exists & valid ───
  # acme.sh exits 2 in this case; treat as success if the cer file is there.
  if [[ $issue_rc -ne 0 ]] && echo "$LAST_ACME_OUT" | grep -qiE "Domains not changed|Skipping.*Next renewal"; then
    if [[ -f "$acme_cert_path" ]]; then
      info "acme.sh: existing cert still valid — using it as-is"
      issue_rc=0
    else
      # The 'skip' message lied (no cert on disk) — force re-issue
      warn "acme.sh says 'skip' but no cert file found — forcing re-issue with --force"
      issue_rc=0
      if [[ "$port80_used" == "true" ]] && ! { command -v nginx &>/dev/null && [[ -d /var/www/html ]]; }; then
        systemctl stop xray 2>/dev/null || true
        sleep 2
        _run_acme_issue standalone "--force" || issue_rc=$?
        systemctl start xray 2>/dev/null || true
      elif [[ "$port80_used" == "true" ]]; then
        _run_acme_issue webroot "--force" || issue_rc=$?
      else
        _run_acme_issue standalone "--force" || issue_rc=$?
      fi
    fi
  fi

  # ── If issue failed, try clearing stale acme.sh state and retry once ───
  # acme.sh caches the CA directory URL and account info. If a previous run
  # picked up ZeroSSL (which fails for many users) or got a stale account
  # token, future runs reuse it and keep failing. Wipe and retry with
  # Let's Encrypt forced.
  if [[ $issue_rc -ne 0 ]] || [[ ! -f "$acme_cert_path" ]]; then
    warn "First SSL attempt failed — clearing acme.sh CA/account cache and retrying..."
    rm -rf "$HOME/.acme.sh/ca" 2>/dev/null || true
    rm -f  "$HOME/.acme.sh/account.conf" 2>/dev/null || true
    # Re-register account explicitly against Let's Encrypt
    "$ACME_CMD" --register-account -m "$CFG_EMAIL" --server letsencrypt 2>&1 | \
      grep -iE "register|account|created" | head -3 || true
    "$ACME_CMD" --set-default-ca --server letsencrypt 2>&1 | tail -3 || true

    issue_rc=0
    if [[ "$port80_used" == "true" ]] && ! { command -v nginx &>/dev/null && [[ -d /var/www/html ]]; }; then
      systemctl stop xray 2>/dev/null || true
      sleep 2
      _run_acme_issue standalone "--force" || issue_rc=$?
      systemctl start xray 2>/dev/null || true
    elif [[ "$port80_used" == "true" ]]; then
      _run_acme_issue webroot "--force" || issue_rc=$?
    else
      _run_acme_issue standalone "--force" || issue_rc=$?
    fi
  fi

  # ── Verify the cert file actually exists before installcert ─
  if [[ $issue_rc -ne 0 ]] || [[ ! -f "$acme_cert_path" ]]; then
    fail "acme.sh --issue failed (exit ${issue_rc}). No cert at ${acme_cert_path}"
    info "Common causes:"
    info "  • DNS A-record for ${CFG_DOMAIN} not pointing to this server's public IP"
    info "  • Cloudflare proxy enabled (orange cloud must be DNS-only / gray)"
    info "  • Port 80 not reachable from internet (provider firewall / security group)"
    info "  • Let's Encrypt rate-limit hit (5 certs/week per domain)"
    info "  • Server IP geo-blocked by Let's Encrypt (Iran sanctions)"
    info ""
    info "Manual recovery on server:"
    info "  rm -rf /root/.acme.sh/ca /root/.acme.sh/account.conf"
    info "  $ACME_CMD --register-account -m $CFG_EMAIL --server letsencrypt"
    info "  $ACME_CMD --issue -d $CFG_DOMAIN --standalone --keylength ec-256 --listen-v4 --server letsencrypt --force"
    autofix_diagnose "SSL"
    return 1
  fi

  ok "acme.sh certificate ready"

  # ── Install certificate to target dir ──────────────────────
  # --ecc selects the EC-key cert directory (${domain}_ecc/). Omit it for RSA.
  local ecc_flag="--ecc"
  [[ "$acme_cert_path" == *"${CFG_DOMAIN}/${CFG_DOMAIN}.cer" ]] && ecc_flag=""
  "$ACME_CMD" --installcert -d "$CFG_DOMAIN" $ecc_flag \
    --cert-file     "${SSL_DIR}/cert.pem" \
    --key-file      "${SSL_KEY}" \
    --fullchain-file "${SSL_CERT}" \
    --reloadcmd     "systemctl restart xray 2>/dev/null || true" 2>&1 | tail -5

  if [[ -f "$SSL_CERT" && -f "$SSL_KEY" ]]; then
    chmod 644 "$SSL_CERT" 2>/dev/null || true
    chmod 640 "$SSL_KEY"  2>/dev/null || true
    chgrp nobody "$SSL_KEY" 2>/dev/null || true
    chmod o+x /etc/ssl/xhttp 2>/dev/null || true
    chmod o+x "$(dirname "$SSL_KEY")" 2>/dev/null || true
    ok "SSL certificate installed → $SSL_CERT"
    # Restart any web services we stopped to free port 80
    if [[ ${#STOPPED_SERVICES[@]} -gt 0 ]]; then
      _restart_stopped_services
    fi
    # IMPORTANT: explicit `return 0` — the `[[ -gt 0 ]] && cmd` pattern above
    # would return 1 if STOPPED_SERVICES is empty (the normal case), tricking
    # autofix_and_retry into thinking SSL failed even when it succeeded.
    return 0
  else
    fail "SSL installcert failed — cert was issued but not copied to ${SSL_CERT}"
    info "Manually try: $ACME_CMD --installcert -d $CFG_DOMAIN --ecc --cert-file ... --key-file ... --fullchain-file ..."
    if [[ ${#STOPPED_SERVICES[@]} -gt 0 ]]; then
      _restart_stopped_services
    fi
    autofix_diagnose "SSL"
    return 1
  fi
}

# =============================================================
#  PHASE 4b — CONFIGURE XRAY (VLESS+XHTTP+TLS)
# =============================================================
phase4b_configure_xray() {
  step "PHASE 4b — Configuring Xray VLESS+XHTTP+TLS inbound"

  local XRAY_CFG="/usr/local/etc/xray/config.json"

  # ── Generate UUID ────────────────────────────────────────
  INBOUND_UUID=$(uuidgen | tr '[:upper:]' '[:lower:]')
  info "Generated UUID: ${INBOUND_UUID}"

  # ── Backup old config ────────────────────────────────────
  [[ -f "$XRAY_CFG" ]] && cp "$XRAY_CFG" "${XRAY_CFG}.bak" 2>/dev/null || true

  # ── Platform-specific XHTTP tuning ───────────────────────
  # Vercel: default padding 100-1000 works fine.
  # Netlify: needs obfuscation-mode padding (10-50 + random key/header) to
  #          survive Netlify's edge body handling. The same key/header MUST
  #          be present in the client link's `extra` param or traffic is rejected.
  # NOTE: do NOT declare XPADDING / XPADDING_KEY / XPADDING_HEADER / SC_MAX_POST_BYTES
  # as `local` here — they need to outlive this function so phase6_summary and
  # phase7_install_panel can embed them in the VLESS link. The `local` keyword
  # confines them to this function's scope (export doesn't override that).
  local XHTTP_MODE="auto"
  local XHTTP_EXTRA_BLOCK=""        # extra JSON properties for xray xhttpSettings
  XPADDING=""
  XPADDING_KEY=""
  XPADDING_HEADER=""
  XPADDING_OBFS="false"
  SC_MAX_POST_BYTES=""

  if [[ "${CFG_PLATFORM:-vercel}" == "netlify" ]]; then
    XPADDING="10-50"
    XPADDING_OBFS="true"
    SC_MAX_POST_BYTES="1000000"
    # Random key (lowercase, 7 chars) and header (mixed-case, 7 chars).
    # /dev/urandom may produce no bytes in some environments — fall back to RANDOM.
    XPADDING_KEY=$(LC_ALL=C tr -dc 'a-z' </dev/urandom 2>/dev/null | head -c 7 || true)
    XPADDING_HEADER=$(LC_ALL=C tr -dc 'A-Za-z' </dev/urandom 2>/dev/null | head -c 7 || true)
    [[ -z "$XPADDING_KEY"    ]] && XPADDING_KEY="k$(printf '%06d' $RANDOM)"
    [[ -z "$XPADDING_HEADER" ]] && XPADDING_HEADER="H$(printf '%06d' $RANDOM)"

    info "Platform=netlify → xPaddingBytes=${XPADDING}, obfsMode=on"
    info "Generated xPaddingKey    : ${XPADDING_KEY}"
    info "Generated xPaddingHeader : ${XPADDING_HEADER}"

    XHTTP_EXTRA_BLOCK=",
          \"xPaddingObfsMode\": true,
          \"xPaddingKey\": \"${XPADDING_KEY}\",
          \"xPaddingHeader\": \"${XPADDING_HEADER}\",
          \"scMaxEachPostBytes\": \"${SC_MAX_POST_BYTES}\""
  else
    XPADDING="100-1000"
  fi

  # Export so phase6_summary + phase7_install_panel can reuse them in the VLESS link
  export XPADDING XPADDING_KEY XPADDING_HEADER XPADDING_OBFS SC_MAX_POST_BYTES

  # ── Write config.json ────────────────────────────────────
  info "Writing Xray config → ${XRAY_CFG}"
  cat > "$XRAY_CFG" <<XRAYCFG
{
  "log": {
    "loglevel": "warning",
    "access": "/var/log/xray/access.log",
    "error": "/var/log/xray/error.log"
  },
  "inbounds": [
    {
      "tag": "xhttp-in",
      "listen": "0.0.0.0",
      "port": ${CFG_INBOUND_PORT},
      "protocol": "vless",
      "settings": {
        "clients": [
          { "id": "${INBOUND_UUID}", "flow": "" }
        ],
        "decryption": "none"
      },
      "streamSettings": {
        "network": "xhttp",
        "security": "tls",
        "tlsSettings": {
          "alpn": ["h2", "http/1.1"],
          "certificates": [
            {
              "certificateFile": "${SSL_CERT}",
              "keyFile": "${SSL_KEY}"
            }
          ]
        },
        "xhttpSettings": {
          "path": "${CFG_RELAY_PATH}",
          "host": "${CFG_DOMAIN}",
          "mode": "${XHTTP_MODE}",
          "xPaddingBytes": "${XPADDING}"${XHTTP_EXTRA_BLOCK}
        }
      }
    }
  ],
  "outbounds": [
    { "protocol": "freedom", "tag": "direct" },
    { "protocol": "blackhole", "tag": "blocked" }
  ]
}
XRAYCFG

  # ── Test config syntax ───────────────────────────────────
  local test_out
  test_out=$(xray -test -config "$XRAY_CFG" 2>&1 || true)
  if echo "$test_out" | grep -qi "configuration ok\|Configuration OK"; then
    ok "Xray config syntax OK"
  else
    fail "Xray config test failed: $test_out"
    autofix_diagnose "XRAY"
    return 1
  fi

  # ── Start Xray ───────────────────────────────────────────
  # ── Force xray to run as root via systemd drop-in (overrides any service file) ──
  # Keep CAP_NET_BIND_SERVICE so xray can bind to privileged ports (443, etc.)
  mkdir -p /etc/systemd/system/xray.service.d
  cat > /etc/systemd/system/xray.service.d/override.conf <<'OVERRIDE'
[Service]
User=root
Group=root
AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
NoNewPrivileges=false
OVERRIDE
  # Also patch any User=nobody in main service files (belt + suspenders)
  for svc in /etc/systemd/system/xray.service /etc/systemd/system/xray@.service /lib/systemd/system/xray.service; do
    [[ -f "$svc" ]] && sed -i 's/^User=nobody/User=root/; s/^Group=nogroup/Group=root/' "$svc" 2>/dev/null || true
  done
  # Ensure log dir is owned by root (xray now runs as root)
  chown -R root:root /var/log/xray 2>/dev/null || true
  chmod 755 /var/log/xray 2>/dev/null || true
  chmod 644 /var/log/xray/*.log 2>/dev/null || true
  systemctl daemon-reload 2>/dev/null || true
  ok "xray service forced to User=root via drop-in"

  systemctl restart xray 2>/dev/null || true
  systemctl enable xray 2>/dev/null || true
  sleep 3

  if systemctl is-active --quiet xray 2>/dev/null; then
    ok "Xray running on port ${CFG_INBOUND_PORT}"
  else
    fail "Xray failed to start"
    journalctl -u xray -n 20 --no-pager 2>/dev/null || true
    autofix_diagnose "XRAY"
    return 1
  fi

  # ── Quick local test ─────────────────────────────────────
  local http_code
  http_code=$(curl -sk --max-time 5 \
    "https://127.0.0.1:${CFG_INBOUND_PORT}${CFG_RELAY_PATH}" \
    -o /dev/null -w "%{http_code}" 2>/dev/null || echo "000")
  if echo "$http_code" | grep -qE "^(4[0-9]{2}|200)$"; then
    ok "Xray local test: HTTP $http_code (expected 4xx) ✔"
  else
    warn "Xray local test returned HTTP $http_code (may be normal for XHTTP)"
  fi

  ok "UUID: ${INBOUND_UUID}"
  echo -e "  ${C_GRAY}TARGET_DOMAIN: https://${CFG_DOMAIN}:${CFG_INBOUND_PORT}${C_RESET}"
}

# =============================================================
#  PHASE 4c — DEPLOY (Vercel or Netlify)
# =============================================================

_random_str() { cat /dev/urandom | tr -dc 'a-z0-9' 2>/dev/null | head -c "$1" || true; }

_randomize_package_json() {
  local pkg="${VERCEL_DIR}/package.json"
  [[ -f "$pkg" ]] || return
  ORIG_PKG=$(cat "$pkg")
  local rname rver rdesc
  rname="host-$(_random_str 10)"
  rver="$(( RANDOM % 3 + 1 )).$((RANDOM % 20)).$((RANDOM % 30))"
  local descs=("Lightweight hosting edge relay" "Optimized download gateway" "Traffic-shaped relay runtime" "Resource-friendly transfer bridge")
  rdesc="${descs[$((RANDOM % ${#descs[@]}))]}"
  jq --arg n "$rname" --arg v "$rver" --arg d "$rdesc" \
    '.name=$n | .version=$v | .description=$d' "$pkg" > "${pkg}.tmp" && mv "${pkg}.tmp" "$pkg"
  info "Randomized package.json: name=$rname, version=$rver"
}

_restore_package_json() {
  local pkg="${VERCEL_DIR}/package.json"
  [[ -n "${ORIG_PKG:-}" ]] && echo "$ORIG_PKG" > "$pkg" && info "package.json restored"
}

_randomize_vercel_json() {
  # NOTE: previously added a `name` field to vercel.json for obfuscation,
  # but recent Vercel CLI rejects vercel.json containing `name` with the
  # misleading error: "The value of the `version` property within vercel.json
  # can only be `2`." (Vercel sees `name`, assumes legacy v1 schema, fails.)
  # Project-name obfuscation now happens via package.json only.
  ORIG_VCFG=""
  return 0
}

_restore_vercel_json() {
  # Kept for compatibility — randomization is now a no-op so there's
  # nothing to restore. If ORIG_VCFG is set (legacy install state), still
  # restore it to be safe.
  local vcfg="${VERCEL_DIR}/vercel.json"
  [[ -n "${ORIG_VCFG:-}" ]] && echo "$ORIG_VCFG" > "$vcfg" && info "vercel.json restored"
  return 0
}

_vercel_diagnose_deploy_error() {
  local out="$1"
  echo -e "\n  ${C_MAGENTA}[AutoFix/Vercel]${C_RESET} Analysing deploy error..."

  # ── Token / Auth — match strict patterns to avoid false positives ──
  if echo "$out" | grep -qiE "Error: (Invalid token|Not authorized)|invalid_token|401 Unauthorized|403 Forbidden|expired token"; then
    fail "Auth error — Vercel token is invalid or expired"
    warn "Fix: go to https://vercel.com/account/tokens and create a new token"
    warn "Then re-run this script and paste the new token"
    return 1
  fi

  # ── Rate limit ──────────────────────────────────────────
  if echo "$out" | grep -qiE "rate.limit|too many requests|429 Too|deployment limit"; then
    fail "Rate limit hit on Vercel API"
    warn "Fix: wait 60 seconds and retry"
    sleep 60
    return 0
  fi

  # ── Project name conflict ─ (owner mismatch / already taken globally) ──
  if echo "$out" | grep -qiE "project.*already exists|name.*already.*taken|409 Conflict"; then
    local new_name
    new_name="relay-$(_random_str 8)"
    warn "Project name conflict — renaming to: $new_name"
    CFG_PROJECT_NAME="$new_name"
    rm -rf "${VERCEL_DIR}/.vercel" 2>/dev/null || true
    return 0
  fi

  # ── Link / project.json stale ─ specific Vercel messages only ────
  if echo "$out" | grep -qiE "project not found|no project linked|linked to a different|\.vercel directory is invalid"; then
    warn "Stale project link — clearing .vercel cache (will re-link before retry)"
    rm -rf "${VERCEL_DIR}/.vercel" 2>/dev/null || true
    return 0
  fi

  # ── vercel.json schema error (Vercel often shows misleading "version" message) ──
  if echo "$out" | grep -qiE "version.*property.*vercel\.json|vercel\.json.*can only be|vercel\.json.*invalid|unknown.*property.*vercel\.json|Invalid vercel\.json"; then
    fail "vercel.json schema error — Vercel rejected the configuration"
    info "Real error from Vercel:"
    echo "$out" | grep -iE "error:|invalid|cannot|unknown" | head -5 | \
      while IFS= read -r l; do echo -e "  ${C_GRAY}    $l${C_RESET}"; done

    if command -v jq &>/dev/null && [[ -f "${VERCEL_DIR}/vercel.json" ]]; then
      warn "Auto-fix: cleaning vercel.json of deprecated properties..."
      # Strip every property known to break recent Vercel CLI:
      #   .name           — deprecated, makes Vercel think v1 schema
      #   .functions[].regions  — per-function regions removed
      #   .regions        — only allowed on Pro/Enterprise plans
      #   .$schema        — JSON Schema reference, some CLI builds reject
      #   .builds         — legacy v1 build config
      #   .routes         — replaced by rewrites/redirects
      jq 'del(.name) | del(.["$schema"]) | del(.builds) | del(.routes) | del(.regions)
          | if .functions then
              .functions = (.functions | with_entries(.value |= del(.regions)))
            else . end' \
          "${VERCEL_DIR}/vercel.json" > "${VERCEL_DIR}/vercel.json.tmp" && \
        mv "${VERCEL_DIR}/vercel.json.tmp" "${VERCEL_DIR}/vercel.json"
      ok "Cleaned vercel.json (removed: name, \$schema, builds, routes, regions, functions.*.regions)"
      info "Current vercel.json:"
      cat "${VERCEL_DIR}/vercel.json" | head -20 | \
        while IFS= read -r l; do echo -e "  ${C_GRAY}    $l${C_RESET}"; done
    else
      warn "jq not available — cannot auto-clean vercel.json"
    fi
    return 0
  fi

  # ── Build failure ───────────────────────────────────────
  if echo "$out" | grep -qiE "Build (failed|error)|Failed to compile|npm ERR!|Module not found"; then
    fail "Build failed inside Vercel"
    warn "Check: api/index.js exists, package.json is valid, vercel.json is correct"
    _restore_vercel_json 2>/dev/null || true
    _restore_package_json 2>/dev/null || true
    return 1
  fi

  # ── Network / DNS from server ───────────────────────────
  if echo "$out" | grep -qiE "ENOTFOUND|ETIMEDOUT|getaddrinfo|network unreachable|connect ECONNREFUSED"; then
    fail "Network error reaching vercel.com from this server"
    warn "Check: curl -I https://vercel.com"
    curl -sI --max-time 5 https://vercel.com | head -3 || true
    return 1
  fi

  # ── Scope / team error — strict patterns ────────────────
  if echo "$out" | grep -qiE "scope .* not found|team .* (not found|does not exist)|not a member of|invalid scope"; then
    warn "Scope/team error — clearing scope and retrying without team"
    CFG_VERCEL_SCOPE=""
    return 0
  fi

  # ── Generic fallback ────────────────────────────────────
  warn "Unknown deploy error — last 15 lines:"
  echo "$out" | tail -15 | while IFS= read -r l; do echo -e "  ${C_GRAY}  $l${C_RESET}"; done
  warn "Try: check https://vercel.com/dashboard for error details"
  return 1
}

phase4c_vercel_deploy() {
  step "PHASE 4c — Deploying to Vercel"

  # ── IMPORTANT pre-deploy notice about Deployment Protection ──
  echo -e "  ${C_YELLOW}⚠ IMPORTANT:${C_RESET} ${C_WHITE}Vercel Deployment Protection MUST be OFF${C_RESET}"
  echo -e "  ${C_GRAY}    If you have Pro/Team plan, go to:${C_RESET}"
  echo -e "  ${C_GRAY}    Team Settings → Deployment Protection → Default Protection → Disabled${C_RESET}"
  echo -e "  ${C_GRAY}    Otherwise the relay returns HTTP 401 and Xray cannot proxy traffic.${C_RESET}"
  echo ""

  if [[ ! -d "$VERCEL_DIR" ]]; then
    fail "vercel/ directory not found. Expected at: $VERCEL_DIR"
    return 1
  fi
  pushd "$VERCEL_DIR" > /dev/null

  export VERCEL_TOKEN="${CFG_VERCEL_TOKEN}"

  # ── Validate token (re-prompt if invalid) ───────────────
  # Success output: just a username on one line, exit 0.
  # Failure output: contains "Error:" prefix or known auth keywords, exit !=0.
  local whoami_out whoami_rc attempt=0
  while [[ $attempt -lt 3 ]]; do
    attempt=$(( attempt + 1 ))
    whoami_out=$(vercel whoami --token "$CFG_VERCEL_TOKEN" 2>&1); whoami_rc=$?
    # Only treat as failure if exit code != 0 OR output starts with explicit Error:
    if [[ $whoami_rc -ne 0 ]] || echo "$whoami_out" | grep -qiE "^(\s*)?Error:|invalid token|forbidden|401|403|unauthorized"; then
      fail "Vercel token invalid (attempt $attempt/3)"
      info "Server response: $(echo "$whoami_out" | head -3)"
      warn "Get a token from: https://vercel.com/account/tokens"
      [[ $attempt -ge 3 ]] && { fail "Cannot authenticate to Vercel after 3 attempts."; popd > /dev/null; return 1; }
      CFG_VERCEL_TOKEN=$(read_secret "Paste new Vercel token")
      export VERCEL_TOKEN="${CFG_VERCEL_TOKEN}"
    else
      ok "Vercel auth OK: $(echo "$whoami_out" | head -1 | tr -d '[:space:]')"
      break
    fi
  done

  # ── Create / ensure project ─────────────────────────────
  local scope_args=()
  [[ -n "${CFG_VERCEL_SCOPE:-}" ]] && scope_args=(--scope "$CFG_VERCEL_SCOPE")

  info "Creating Vercel project '${CFG_PROJECT_NAME}'..."
  local proj_out proj_rc
  proj_out=$(vercel project add "$CFG_PROJECT_NAME" --token "$CFG_VERCEL_TOKEN" \
    "${scope_args[@]}" 2>&1); proj_rc=$?
  # exit 0 = created. exit !=0 might mean "already exists" (we treat that as OK)
  if [[ $proj_rc -eq 0 ]]; then
    ok "Project created: $CFG_PROJECT_NAME"
  elif echo "$proj_out" | grep -qiE "already exists|Project found"; then
    ok "Project already exists — reusing"
  else
    warn "Project add returned $proj_rc — continuing (link step will catch real errors)"
    echo "$proj_out" | tail -5 | while IFS= read -r l; do echo -e "  ${C_GRAY}  $l${C_RESET}"; done
  fi

  # ── Link helper — re-runnable from anywhere in the flow ─────
  _vercel_link() {
    rm -rf "${VERCEL_DIR}/.vercel" 2>/dev/null || true
    local link_out link_rc
    link_out=$(vercel link --yes --project "$CFG_PROJECT_NAME" \
      --token "$CFG_VERCEL_TOKEN" "${scope_args[@]}" 2>&1); link_rc=$?
    if [[ $link_rc -ne 0 ]] && ! echo "$link_out" | grep -qiE "Linked to|Already linked"; then
      warn "Link failed:"
      echo "$link_out" | tail -5 | while IFS= read -r l; do echo -e "  ${C_GRAY}  $l${C_RESET}"; done
      return 1
    fi
    return 0
  }

  info "Linking to project..."
  _vercel_link || { fail "Could not link to project $CFG_PROJECT_NAME"; popd > /dev/null; return 1; }
  ok "Linked to $CFG_PROJECT_NAME"

  # ── Disable Deployment Protection via REST API ──────────
  # Pro/Team accounts often have ssoProtection / passwordProtection enabled by
  # default; this returns HTTP 401 on every request to the deployment and
  # breaks the relay. Vercel API allows clearing both fields.
  info "Disabling Deployment Protection on the project (if applicable)..."
  local api_url="https://api.vercel.com/v9/projects/${CFG_PROJECT_NAME}"
  [[ -n "${CFG_VERCEL_SCOPE:-}" ]] && api_url="${api_url}?teamId=${CFG_VERCEL_SCOPE}"
  local prot_out prot_code
  prot_out=$(curl -s -o /tmp/.vercel-prot-resp -w "%{http_code}" --max-time 10 \
    -X PATCH "$api_url" \
    -H "Authorization: Bearer ${CFG_VERCEL_TOKEN}" \
    -H "Content-Type: application/json" \
    --data '{"ssoProtection":null,"passwordProtection":null}' 2>/dev/null || echo "000")
  prot_code="$prot_out"
  if [[ "$prot_code" == "200" ]]; then
    ok "Deployment Protection disabled via API"
  elif [[ "$prot_code" == "403" ]]; then
    info "Cannot disable via API (Hobby plan — protection already off by default)"
  else
    warn "Could not disable Deployment Protection via API (HTTP ${prot_code})"
    info "If deploy returns 401 later, disable manually at:"
    info "  https://vercel.com/dashboard → ${CFG_PROJECT_NAME} → Settings → Deployment Protection"
    [[ -s /tmp/.vercel-prot-resp ]] && head -3 /tmp/.vercel-prot-resp | \
      while IFS= read -r l; do info "  $l"; done
  fi
  rm -f /tmp/.vercel-prot-resp

  # ── ENV vars ────────────────────────────────────────────
  info "Setting environment variables (via stdin — required by recent Vercel CLI)..."
  local TARGET_DOMAIN_VAL="https://${CFG_DOMAIN}:${CFG_INBOUND_PORT}"

  # Recent Vercel CLI deprecated --value flag. Now `vercel env add` reads the
  # value from stdin. We pipe the value in and the flag is gone.
  _set_env() {
    local name="$1" value="$2" out rc
    # Try stdin-style (current CLI behavior)
    out=$(printf '%s' "$value" | vercel env add "$name" production --force \
          --token "$CFG_VERCEL_TOKEN" "${scope_args[@]}" 2>&1 </dev/stdin); rc=$?
    # Older CLIs that still accept --value: fall back if stdin form failed
    if [[ $rc -ne 0 ]] && ! echo "$out" | grep -qiE "added|created|updated|overwrote|saved"; then
      out=$(vercel env add "$name" production --value "$value" --force --yes \
            --token "$CFG_VERCEL_TOKEN" "${scope_args[@]}" 2>&1); rc=$?
    fi
    if [[ $rc -eq 0 ]] || echo "$out" | grep -qiE "added|created|updated|overwrote|saved"; then
      info "  ✓ ${name}"
    else
      warn "  ! ${name} (rc=$rc): $(echo "$out" | head -1)"
    fi
  }
  _set_env "TARGET_DOMAIN"               "$TARGET_DOMAIN_VAL"
  _set_env "RELAY_PATH"                  "$CFG_RELAY_PATH"
  _set_env "PUBLIC_RELAY_PATH"           "$CFG_PUBLIC_PATH"
  _set_env "MAX_INFLIGHT"                "$CFG_MAX_INFLIGHT"
  _set_env "MAX_UP_BPS"                  "$CFG_MAX_UP_BPS"
  _set_env "MAX_DOWN_BPS"                "$CFG_MAX_DOWN_BPS"
  _set_env "UPSTREAM_TIMEOUT_MS"         "$CFG_UPSTREAM_TIMEOUT"
  _set_env "SUCCESS_LOG_SAMPLE_RATE"     "$CFG_SUCCESS_LOG"
  _set_env "SUCCESS_LOG_MIN_DURATION_MS" "$CFG_SUCCESS_DUR"
  _set_env "ERROR_LOG_MIN_INTERVAL_MS"   "$CFG_ERROR_INT"

  # ── Verify ENVs actually landed on Vercel ─────────────────
  local env_list
  env_list=$(vercel env ls production --token "$CFG_VERCEL_TOKEN" "${scope_args[@]}" 2>&1 || true)
  if echo "$env_list" | grep -q "TARGET_DOMAIN"; then
    ok "ENV variables verified on Vercel"
  else
    warn "Could not verify ENV vars — values may not have landed."
    echo "$env_list" | head -10 | while IFS= read -r l; do echo -e "  ${C_GRAY}  $l${C_RESET}"; done
  fi

  # ── Deploy with retry ───────────────────────────────────
  local deploy_attempt=0 deploy_out deploy_url=""
  while [[ $deploy_attempt -lt $AUTOFIX_MAX ]]; do
    deploy_attempt=$(( deploy_attempt + 1 ))
    info "Deploy attempt $deploy_attempt/$AUTOFIX_MAX..."

    _randomize_package_json
    _randomize_vercel_json

    deploy_out=$(vercel deploy --prod --yes \
      --token "$CFG_VERCEL_TOKEN" "${scope_args[@]}" 2>&1) && {
      _restore_vercel_json; _restore_package_json; break
    }
    _restore_vercel_json; _restore_package_json

    fail "Deploy attempt $deploy_attempt failed"
    if ! _vercel_diagnose_deploy_error "$deploy_out"; then
      [[ $deploy_attempt -ge $AUTOFIX_MAX ]] && { fail "Deploy failed after $AUTOFIX_MAX attempts. See: $LOG_FILE"; popd > /dev/null; return 1; }
    fi
    # refresh scope_args in case CFG_VERCEL_SCOPE was cleared by diagnose
    scope_args=()
    [[ -n "${CFG_VERCEL_SCOPE:-}" ]] && scope_args=(--scope "$CFG_VERCEL_SCOPE")
    # If diagnose cleared .vercel cache, we MUST re-link before next deploy
    if [[ ! -d "${VERCEL_DIR}/.vercel" ]]; then
      info "Re-linking project after cache clear..."
      _vercel_link || warn "Re-link failed — next deploy may still fail"
    fi
    sleep 3
  done

  # ── Extract URL ─────────────────────────────────────────
  deploy_url=$(echo "$deploy_out" | grep -oP 'https://[^\s]+\.vercel\.app' | tail -1 || true)
  [[ -z "$deploy_url" ]] && \
    deploy_url=$(echo "$deploy_out" | grep -iE 'production|preview' | grep -oP 'https://\S+\.vercel\.app' | tail -1 || true)

  if [[ -n "$deploy_url" ]]; then
    VERCEL_URL="$deploy_url"
    ok "Production URL: ${VERCEL_URL}"

    # ── Detect Deployment Protection (returns 401 + Vercel SSO page) ──
    info "Checking for Vercel Deployment Protection..."
    local probe_code probe_body
    probe_code=$(curl -sk -o /dev/null --max-time 10 -w "%{http_code}" "$VERCEL_URL" 2>/dev/null || echo "000")
    probe_body=$(curl -sk --max-time 10 "$VERCEL_URL" 2>/dev/null | head -c 500)

    if [[ "$probe_code" == "401" ]] || echo "$probe_body" | grep -qi "Authentication Required\|_vercel_sso\|sso\.vercel\.com"; then
      warn "Deployment Protection still ENABLED (HTTP 401) — disabling via API..."

      # ── Try project-level API again (more aggressive, with retries) ──
      local prot_api_url="https://api.vercel.com/v9/projects/${CFG_PROJECT_NAME}"
      [[ -n "${CFG_VERCEL_SCOPE:-}" ]] && prot_api_url="${prot_api_url}?teamId=${CFG_VERCEL_SCOPE}"
      local attempt2=0 prot_rc=""
      while [[ $attempt2 -lt 3 ]]; do
        attempt2=$(( attempt2 + 1 ))
        prot_rc=$(curl -s -o /tmp/.vp -w "%{http_code}" --max-time 12 \
          -X PATCH "$prot_api_url" \
          -H "Authorization: Bearer ${CFG_VERCEL_TOKEN}" \
          -H "Content-Type: application/json" \
          --data '{"ssoProtection":null,"passwordProtection":null}' 2>/dev/null || echo "000")
        if [[ "$prot_rc" == "200" ]]; then
          ok "Deployment Protection disabled via API"
          break
        fi
        info "API attempt ${attempt2}/3 → HTTP ${prot_rc}"
        sleep 2
      done

      # ── Also try team-level Default Protection (Pro/Team only) ──
      if [[ -n "${CFG_VERCEL_SCOPE:-}" ]] && [[ "$prot_rc" != "200" ]]; then
        info "Trying team-level Default Protection..."
        curl -s -o /tmp/.vp -w "%{http_code}" --max-time 12 \
          -X PATCH "https://api.vercel.com/v2/teams/${CFG_VERCEL_SCOPE}" \
          -H "Authorization: Bearer ${CFG_VERCEL_TOKEN}" \
          -H "Content-Type: application/json" \
          --data '{"defaultProtection":"disabled"}' >/dev/null 2>&1 || true
      fi
      rm -f /tmp/.vp

      # ── Force a fresh deploy so the new protection setting takes effect ──
      info "Re-deploying so protection-disabled setting takes effect..."
      _randomize_package_json
      local redeploy_out
      redeploy_out=$(vercel deploy --prod --yes \
        --token "$CFG_VERCEL_TOKEN" "${scope_args[@]}" 2>&1 || true)
      _restore_package_json
      local new_url
      new_url=$(echo "$redeploy_out" | grep -oP 'https://[^\s]+\.vercel\.app' | tail -1 || true)
      [[ -n "$new_url" ]] && VERCEL_URL="$new_url"

      # ── Verify protection is now off ──
      sleep 3
      probe_code=$(curl -sk -o /dev/null --max-time 10 -w "%{http_code}" "$VERCEL_URL" 2>/dev/null || echo "000")
      probe_body=$(curl -sk --max-time 10 "$VERCEL_URL" 2>/dev/null | head -c 500)
      if [[ "$probe_code" != "401" ]] && ! echo "$probe_body" | grep -qi "Authentication Required\|_vercel_sso"; then
        ok "Deployment Protection successfully disabled (HTTP ${probe_code})"
      else
        # API path didn't work (Hobby plan can't even use the API, or token lacks perms).
        # Fall back to manual instructions but keep them short.
        fail "Could not disable Deployment Protection automatically"
        echo ""
        echo -e "  ${C_YELLOW}Please disable it manually (one-time, takes 10 seconds):${C_RESET}"
        echo -e "    1. https://vercel.com/dashboard → ${CFG_PROJECT_NAME} → Settings → Deployment Protection"
        echo -e "    2. Set ${C_YELLOW}Vercel Authentication${C_RESET} and ${C_YELLOW}Password Protection${C_RESET} both to ${C_GREEN}Disabled${C_RESET}"
        echo -e "    3. Re-run this script or open ${C_WHITE}xhttp${C_RESET} panel → Update / Re-deploy"
        echo ""
      fi
    else
      ok "Deployment Protection check: OK (HTTP ${probe_code})"
    fi
  else
    warn "Could not parse production URL — check Vercel dashboard"
    VERCEL_URL="(check dashboard)"
    echo "$deploy_out" | tail -8
  fi

  popd > /dev/null
}

phase4c_netlify_deploy() {
  step "PHASE 4c — Deploying to Netlify"

  if [[ ! -d "$NETLIFY_DIR" ]]; then
    fail "netlify/ directory not found. Expected at: $NETLIFY_DIR"
    return 1
  fi
  info "Netlify project dir: $NETLIFY_DIR"

  local TARGET_DOMAIN_VAL="https://${CFG_DOMAIN}:${CFG_INBOUND_PORT}"
  local attempt=0

  # ── Validate token ───────────────────────────────────────
  while [[ $attempt -lt 3 ]]; do
    attempt=$(( attempt + 1 ))
    local whoami_out
    whoami_out=$(NETLIFY_AUTH_TOKEN="$CFG_NETLIFY_TOKEN" netlify api getCurrentUser 2>&1 || true)
    if echo "$whoami_out" | grep -qiE '"id":|"email":'; then
      local nl_user
      nl_user=$(echo "$whoami_out" | grep -oP '"email"\s*:\s*"\K[^"]+' || echo "ok")
      ok "Netlify auth OK: $nl_user"
      break
    else
      fail "Netlify token invalid (attempt $attempt/3)"
      warn "Get a token from: https://app.netlify.com/user/applications#personal-access-tokens"
      CFG_NETLIFY_TOKEN=$(read_secret "Paste new Netlify token")
    fi
    [[ $attempt -ge 3 ]] && { fail "Cannot authenticate to Netlify after 3 attempts."; return 1; }
  done

  export NETLIFY_AUTH_TOKEN="$CFG_NETLIFY_TOKEN"

  # ── Create or get site ───────────────────────────────────
  info "Creating/finding Netlify site '${CFG_NETLIFY_SITE}'..."
  local site_id
  site_id=$(netlify api listSites 2>/dev/null | \
    grep -oP '"id"\s*:\s*"\K[^"]+(?=.*"name"\s*:\s*"'"${CFG_NETLIFY_SITE}"'")' | head -1 || true)

  if [[ -z "$site_id" ]]; then
    local create_out
    create_out=$(netlify api createSite --data "{\"name\":\"${CFG_NETLIFY_SITE}\"}" 2>/dev/null || true)
    site_id=$(echo "$create_out" | grep -oP '"id"\s*:\s*"\K[^"]+' | head -1 || true)
    [[ -z "$site_id" ]] && { fail "Could not create Netlify site"; return 1; }
    ok "Netlify site created: ${CFG_NETLIFY_SITE} (id: ${site_id})"
  else
    ok "Using existing Netlify site: ${CFG_NETLIFY_SITE} (id: ${site_id})"
  fi
  NETLIFY_SITE_ID="$site_id"

  # ── Set env vars ─────────────────────────────────────────
  info "Setting Netlify env var: TARGET_DOMAIN=${TARGET_DOMAIN_VAL}"
  pushd "$NETLIFY_DIR" > /dev/null
  sleep 3

  local NETLIFY_ACCOUNT_SLUG
  NETLIFY_ACCOUNT_SLUG=$(curl -sS --max-time 15 \
    "https://api.netlify.com/api/v1/sites/${site_id}" \
    -H "Authorization: Bearer ${CFG_NETLIFY_TOKEN}" 2>/dev/null | \
    grep -oP '"account_slug"\s*:\s*"\K[^"]+' | head -1 || true)
  if [[ -z "$NETLIFY_ACCOUNT_SLUG" ]]; then
    NETLIFY_ACCOUNT_SLUG=$(curl -sS --max-time 15 \
      "https://api.netlify.com/api/v1/accounts" \
      -H "Authorization: Bearer ${CFG_NETLIFY_TOKEN}" 2>/dev/null | \
      grep -oP '"slug"\s*:\s*"\K[^"]+' | head -1 || true)
  fi

  _netlify_set_env_api() {
    local key="$1" value="$2"
    local api_base="https://api.netlify.com/api/v1/accounts/${NETLIFY_ACCOUNT_SLUG}/env"
    [[ -z "$NETLIFY_ACCOUNT_SLUG" ]] && { warn "  no account_slug — cannot use REST API"; return 1; }

    _try_body() {
      local body="$1"
      local api_out
      api_out=$(curl -sS --max-time 20 -X POST "${api_base}?site_id=${site_id}" \
        -H "Authorization: Bearer ${CFG_NETLIFY_TOKEN}" -H "Content-Type: application/json" -d "$body" 2>&1 || true)
      if echo "$api_out" | grep -qE "\"key\"\s*:\s*\"${key}\""; then return 0; fi
      if echo "$api_out" | grep -qiE "Upgrade your Netlify account to set specific scopes|scopes"; then
        echo "__SCOPE_NOT_ALLOWED__"; return 1
      fi
      local single_obj="${body#[}"; single_obj="${single_obj%]}"
      api_out=$(curl -sS --max-time 20 -X PUT "${api_base}/${key}?site_id=${site_id}" \
        -H "Authorization: Bearer ${CFG_NETLIFY_TOKEN}" -H "Content-Type: application/json" -d "$single_obj" 2>&1 || true)
      if echo "$api_out" | grep -qE "\"key\"\s*:\s*\"${key}\""; then return 0; fi
      return 1
    }

    curl -sS --max-time 15 -o /dev/null -X DELETE "${api_base}/${key}?site_id=${site_id}" \
      -H "Authorization: Bearer ${CFG_NETLIFY_TOKEN}" >/dev/null 2>&1 || true

    local body_with_scope body_no_scope try_out
    body_with_scope=$(printf '[{"key":"%s","values":[{"value":"%s","context":"production"}],"scopes":["functions"]}]' "$key" "$value")
    try_out=$(_try_body "$body_with_scope" 2>&1)
    if [[ $? -eq 0 ]]; then ok "  ${key} set via REST API (with scope)"; return 0; fi

    body_no_scope=$(printf '[{"key":"%s","values":[{"value":"%s","context":"production"}]}]' "$key" "$value")
    try_out=$(_try_body "$body_no_scope" 2>&1)
    if [[ $? -eq 0 ]]; then ok "  ${key} set via REST API (no scope)"; return 0; fi

    local body_all=$(printf '[{"key":"%s","values":[{"value":"%s","context":"all"}]}]' "$key" "$value")
    if _try_body "$body_all" >/dev/null 2>&1; then ok "  ${key} set via REST API (context=all)"; return 0; fi
    return 1
  }

  local set_ok=false
  _netlify_set_env_api TARGET_DOMAIN "$TARGET_DOMAIN_VAL" && set_ok=true

  if [[ "$set_ok" != "true" ]]; then
    timeout 30 netlify link --id "$site_id" </dev/null >/dev/null 2>&1 || true
    local set_out=$(timeout 30 netlify env:set TARGET_DOMAIN "$TARGET_DOMAIN_VAL" --scope functions --site "$site_id" </dev/null 2>&1 || true)
    if echo "$set_out" | grep -qiE "set environment variable|in the .* context|added|updated|saved"; then
      set_ok=true
    fi
  fi
  popd > /dev/null

  # --- DYNAMIC FINGERPRINT OBFUSCATION START ---
  info "Randomizing Netlify fingerprint..."
  local r_str=$(_random_str 6)
  local func_name="api_$r_str"
  
  local n_pkg="${NETLIFY_DIR}/package.json"
  if command -v jq &>/dev/null && [[ -f "$n_pkg" ]]; then
    jq '.name="app-core-'$r_str'" | .description="Web API Engine" | del(.author) | del(.homepage)' "$n_pkg" > "${n_pkg}.tmp" && mv "${n_pkg}.tmp" "$n_pkg"
  fi

  echo "<!doctype html><html lang='en'><head><title>System $r_str</title></head><body><div id='root'>Initialize...</div></body></html>" > "${NETLIFY_DIR}/public/index.html"

  local n_toml="${NETLIFY_DIR}/netlify.toml"
  sed -i "s/function = \"relay\"/function = \"$func_name\"/g" "$n_toml" 2>/dev/null || true

  rm -f "${NETLIFY_DIR}/netlify/edge-functions/relay.js"
  mkdir -p "${NETLIFY_DIR}/netlify/edge-functions"
  local edge_file="${NETLIFY_DIR}/netlify/edge-functions/${func_name}.js"
  
  local v_tgt="tgt_${r_str}"
  local v_req="req_${r_str}"
  local v_url="url_${r_str}"
  local v_hdrs="hdrs_${r_str}"
  local v_cip="cip_${r_str}"
  
  cat > "$edge_file" <<EOF
export const config = { path: "/*" };
const envKey = ["T","A","R","G","E","T","_","D","O","M","A","I","N"].join("");
const ${v_tgt} = (Netlify.env.get(envKey) || "").replace(/\/$/, "");
const drop = new Set(["host", "connection", "keep-alive", "proxy-authenticate", "proxy-authorization", "te", "trailer", "transfer-encoding", "upgrade", "forwarded"]);

export default async function handler(${v_req}) {
  if (!${v_tgt}) return new Response("Service Unavailable", { status: 500 });
  try {
    const ${v_url} = new URL(${v_req}.url);
    const dest = ${v_tgt} + ${v_url}.pathname + ${v_url}.search;
    const ${v_hdrs} = new Headers();
    let ${v_cip} = null;
    for (const [k, v] of ${v_req}.headers) {
      const lk = k.toLowerCase();
      if (drop.has(lk) || lk.startsWith("x-nf-") || lk.startsWith("x-netlify-")) continue;
      if (lk === "x-real-ip" || (!${v_cip} && lk === "x-forwarded-for")) { ${v_cip} = v; if (lk === "x-real-ip") continue; }
      ${v_hdrs}.set(lk, v);
    }
    if (${v_cip}) ${v_hdrs}.set("x-forwarded-for", ${v_cip});
    
    const opts = { method: ${v_req}.method, headers: ${v_hdrs}, redirect: "manual" };
    if (${v_req}.method !== "GET" && ${v_req}.method !== "HEAD") opts.body = ${v_req}.body;
    
    const up = await fetch(dest, opts);
    const outHdrs = new Headers();
    for (const [k, v] of up.headers) {
      if (k.toLowerCase() !== "transfer-encoding") outHdrs.set(k, v);
    }
    return new Response(up.body, { status: up.status, headers: outHdrs });
  } catch(e) {
    return new Response("Gateway Timeout", { status: 504 });
  }
}
EOF
  # --- DYNAMIC FINGERPRINT OBFUSCATION END ---

  # ── Deploy ───────────────────────────────────────────────
  info "Deploying to Netlify..."
  local deploy_log=$(mktemp)
  pushd "$NETLIFY_DIR" > /dev/null
  netlify deploy --prod --dir public --site "$site_id" 2>&1 | tee "$deploy_log" || true
  popd > /dev/null
  local deploy_out=$(<"$deploy_log")
  rm -f "$deploy_log"

  local cli_url=$(echo "$deploy_out" | grep -oP 'https://[a-z0-9-]+\.netlify\.app' | grep -v -- '--' | head -1 || true)
  [[ -z "$cli_url" ]] && cli_url=$(echo "$deploy_out" | grep -oP 'https://[^\s<>]+\.netlify\.app' | tail -1 || true)

  local cli_failed=false
  if echo "$deploy_out" | grep -qiE "JSONHTTPError|Forbidden|Unauthorized|Error: .* 40[13]|deploy.*failed|access denied"; then cli_failed=true; fi
  [[ -z "$cli_url" ]] && cli_failed=true

  if [[ "$cli_failed" == "true" ]]; then
    info "Trying REST API zip-upload fallback..."
    if ! command -v zip &>/dev/null; then DEBIAN_FRONTEND=noninteractive apt-get install -y -qq zip 2>/dev/null || true; fi
    
    local tmp_zip=$(mktemp --suffix=.zip)
    pushd "$NETLIFY_DIR" > /dev/null
    zip -rq "$tmp_zip" netlify.toml public netlify 2>&1 | tail -3
    popd > /dev/null

    local upload_resp upload_code
    upload_resp=$(curl -s --max-time 90 -w "\n%{http_code}" -X POST "https://api.netlify.com/api/v1/sites/${site_id}/deploys" \
      -H "Authorization: Bearer ${CFG_NETLIFY_TOKEN}" -H "Content-Type: application/zip" --data-binary "@${tmp_zip}" 2>&1 || true)
    rm -f "$tmp_zip"
    upload_code=$(echo "$upload_resp" | tail -1)
    upload_resp=$(echo "$upload_resp" | sed '$d')

    if [[ "$upload_code" == "200" || "$upload_code" == "201" ]]; then
      VERCEL_URL=$(echo "$upload_resp" | grep -oP '"deploy_ssl_url"\s*:\s*"\K[^"]+' | head -1)
      [[ -z "$VERCEL_URL" ]] && VERCEL_URL=$(echo "$upload_resp" | grep -oP '"ssl_url"\s*:\s*"\K[^"]+' | head -1)
      [[ -z "$VERCEL_URL" ]] && VERCEL_URL=$(echo "$upload_resp" | grep -oP '"url"\s*:\s*"\K[^"]+' | head -1)
      if [[ -n "$VERCEL_URL" ]]; then ok "REST API deploy succeeded: ${VERCEL_URL}"; else return 1; fi
    else
      fail "REST API deploy also failed (HTTP ${upload_code})"
      return 1
    fi
  else
    VERCEL_URL="$cli_url"
    ok "Netlify deployed: ${VERCEL_URL}"
  fi

  if [[ -n "${VERCEL_URL:-}" ]]; then
    local verify_attempt=0 edge_ok=false
    while [[ $verify_attempt -lt 3 ]]; do
      verify_attempt=$(( verify_attempt + 1 ))
      sleep 4
      local verify_body verify_code
      verify_body=$(curl -sk -X POST "${VERCEL_URL}${CFG_PUBLIC_PATH}" --max-time 12 -d "ping" 2>&1 || true)
      verify_code=$(curl -sk -o /dev/null -w "%{http_code}" -X POST "${VERCEL_URL}${CFG_PUBLIC_PATH}" --max-time 12 -d "ping" 2>/dev/null || echo "000")

      local need_redeploy=false
      if echo "$verify_body" | grep -qi "Looks like you.ve followed a broken link\|<title>Page not found</title>"; then
        need_redeploy=true
      elif [[ "$verify_code" == "500" ]] && echo "$verify_body" | grep -qi "Misconfigured\|TARGET_DOMAIN"; then
        need_redeploy=true
        _netlify_set_env_api TARGET_DOMAIN "$TARGET_DOMAIN_VAL" || true
      fi

      if [[ "$need_redeploy" == "true" ]]; then
        pushd "$NETLIFY_DIR" > /dev/null
        local deploy_log=$(mktemp)
        netlify deploy --prod --dir public --skip-functions-cache --site "$site_id" 2>&1 | tee "$deploy_log" || true
        popd > /dev/null
        local deploy_out=$(<"$deploy_log")
        rm -f "$deploy_log"
        local new_url=$(echo "$deploy_out" | grep -oP 'https://[a-z0-9-]+\.netlify\.app' | grep -v -- '--' | head -1 || true)
        [[ -n "$new_url" ]] && VERCEL_URL="$new_url"
      else
        edge_ok=true
        ok "Edge function is responding (HTTP ${verify_code}, relay routing + env OK)"
        break
      fi
    done
  fi
}


phase4c_deploy() {
  if [[ "${CFG_PLATFORM:-vercel}" == "netlify" ]]; then
    phase4c_netlify_deploy
  else
    phase4c_vercel_deploy
  fi
}

# helper — redeploy ENV after user corrects a value
_redeploy_env_fix() {
  if [[ "${CFG_PLATFORM:-vercel}" == "netlify" ]]; then
    info "Skipping auto-redeploy on Netlify (manual: re-run script if needed)"
    return 0
  fi
  local scope_args=()
  [[ -n "${CFG_VERCEL_SCOPE:-}" ]] && scope_args=(--scope "$CFG_VERCEL_SCOPE")
  info "Updating ENV on Vercel and redeploying..."
  pushd "$VERCEL_DIR" > /dev/null
  local TARGET_DOMAIN_VAL="https://${CFG_DOMAIN}:${CFG_INBOUND_PORT}"

  # Use stdin-style env add (current Vercel CLI), with --value fallback for older CLIs
  _v_env() {
    local name="$1" value="$2" out rc
    out=$(printf '%s' "$value" | vercel env add "$name" production --force \
          --token "$CFG_VERCEL_TOKEN" "${scope_args[@]}" 2>&1 </dev/stdin); rc=$?
    if [[ $rc -ne 0 ]] && ! echo "$out" | grep -qiE "added|updated|saved"; then
      vercel env add "$name" production --value "$value" --force --yes \
        --token "$CFG_VERCEL_TOKEN" "${scope_args[@]}" 2>/dev/null || true
    fi
  }
  _v_env "TARGET_DOMAIN"     "$TARGET_DOMAIN_VAL"
  _v_env "RELAY_PATH"        "$CFG_RELAY_PATH"
  _v_env "PUBLIC_RELAY_PATH" "$CFG_PUBLIC_PATH"

  _randomize_package_json; _randomize_vercel_json
  local out
  out=$(vercel deploy --prod --yes --token "$CFG_VERCEL_TOKEN" "${scope_args[@]}" 2>&1) && {
    _restore_vercel_json; _restore_package_json
    local url
    url=$(echo "$out" | grep -oP 'https://[^\s]+\.vercel\.app' | tail -1 || true)
    [[ -n "$url" ]] && VERCEL_URL="$url"
    ok "Redeployed: ${VERCEL_URL:-done}"
  } || {
    _restore_vercel_json; _restore_package_json
    fail "Redeploy failed — check $LOG_FILE"
  }
  popd > /dev/null
}

# =============================================================
#  PHASE 5 — HEALTH CHECK WITH xray-knife + CONFIG VALIDATOR
# =============================================================
phase5_healthcheck() {
  step "PHASE 5 — Health check & config validation"

  local TARGET_DOMAIN_VAL="https://${CFG_DOMAIN}:${CFG_INBOUND_PORT}"
  local VERCEL_HOST
  VERCEL_HOST=$(echo "${VERCEL_URL:-}" | sed 's|https://||' | sed 's|/.*||')
  local need_redeploy=false

  # ── Test 1: upstream (Xray) directly ────────────────────
  echo -e "\n  ${C_CYAN}[ Test 1 ] Direct upstream reachability${C_RESET}"
  local http1 direct_ok=false
  http1=$(curl -sk --max-time 8 "${TARGET_DOMAIN_VAL}${CFG_RELAY_PATH}" \
    -o /dev/null -w "%{http_code}" 2>/dev/null || echo "000")
  if echo "$http1" | grep -qE "^(200|400|401|403|404|405)$"; then
    ok "Upstream reachable — HTTP $http1 on ${CFG_DOMAIN}:${CFG_INBOUND_PORT}"
    direct_ok=true
  else
    fail "Upstream NOT reachable (HTTP $http1) at ${TARGET_DOMAIN_VAL}${CFG_RELAY_PATH}"
    if ufw status 2>/dev/null | grep -qi "Status: active"; then
      warn "→ Auto-fix: opening firewall port ${CFG_INBOUND_PORT}..."
      ufw allow "${CFG_INBOUND_PORT}/tcp" 2>/dev/null || true
    fi
    warn "→ Restarting xray..."
    systemctl restart xray 2>/dev/null || true; sleep 3
    # retry once after fix
    http1=$(curl -sk --max-time 8 "${TARGET_DOMAIN_VAL}${CFG_RELAY_PATH}" \
      -o /dev/null -w "%{http_code}" 2>/dev/null || echo "000")
    if echo "$http1" | grep -qE "^(200|400|401|403|404|405)$"; then
      ok "Upstream reachable after fix — HTTP $http1"
      direct_ok=true
    else
      fail "Still unreachable. Check: systemctl status xray / SSL cert / DNS"
    fi
  fi

  # ── Test 2: Relay + smart PATH/TARGET fix ────────────────
  echo -e "\n  ${C_CYAN}[ Test 2 ] Relay & config validation${C_RESET}"
  if [[ -n "$VERCEL_HOST" ]]; then
    local vercel_code
    vercel_code=$(curl -sk --max-time 15 \
      "https://${VERCEL_HOST}${CFG_PUBLIC_PATH}" \
      -o /dev/null -w "%{http_code}" 2>/dev/null || echo "000")

    case "$vercel_code" in
      200|101)
        ok "Vercel relay responding — HTTP $vercel_code" ;;

      404)
        if [[ "$CFG_PUBLIC_PATH" == "/api" ]]; then
          warn "HTTP 404 on ${CFG_PUBLIC_PATH} — normal for VLESS/XHTTP endpoints (browser GET ≠ XHTTP handshake)"
          info "This is expected. Real client traffic should still work."
        else
          fail "HTTP 404 — PUBLIC_RELAY_PATH mismatch"
          info "Current PUBLIC_RELAY_PATH: ${CFG_PUBLIC_PATH}"
          if [[ "$CFG_PLATFORM" == "vercel" ]]; then
            info "Vercel rewrites in vercel.json only support: /api and /api/:path*"
          else
            info "Netlify edge functions need matching path in netlify.toml"
          fi
          warn "AutoFix: correcting PUBLIC_RELAY_PATH -> /api"
          CFG_PUBLIC_PATH="/api"
          need_redeploy=true
        fi ;;

      502)
        fail "HTTP 502 — Relay cannot reach your server (TARGET_DOMAIN wrong or firewall)"
        info "Current TARGET_DOMAIN: ${TARGET_DOMAIN_VAL}"
        if [[ "$direct_ok" == "false" ]]; then
          warn "AutoFix: upstream also unreachable — restarting xray"
          if ufw status 2>/dev/null | grep -qi "Status: active"; then
            ufw allow "${CFG_INBOUND_PORT}/tcp" 2>/dev/null || true
          fi
          systemctl restart xray 2>/dev/null || true; sleep 3
        fi
        warn "Please confirm TARGET_DOMAIN is correct:"
        local new_domain
        new_domain=$(read_default "TARGET_DOMAIN host (domain:port)" "${CFG_DOMAIN}:${CFG_INBOUND_PORT}")
        if [[ "$new_domain" != "${CFG_DOMAIN}:${CFG_INBOUND_PORT}" ]]; then
          CFG_DOMAIN="${new_domain%%:*}"
          CFG_INBOUND_PORT="${new_domain##*:}"
          need_redeploy=true
        fi ;;

      500)
        fail "HTTP 500 — ENV variables missing or wrong on ${CFG_PLATFORM}"
        warn "AutoFix: re-pushing all ENV variables..."
        need_redeploy=true ;;

      503)
        fail "HTTP 503 — MAX_INFLIGHT limit reached"
        warn "AutoFix: doubling MAX_INFLIGHT (${CFG_MAX_INFLIGHT} -> $(( CFG_MAX_INFLIGHT * 2 )))"
        CFG_MAX_INFLIGHT=$(( CFG_MAX_INFLIGHT * 2 ))
        need_redeploy=true ;;

      504)
        fail "HTTP 504 — Upstream timeout"
        warn "AutoFix: doubling UPSTREAM_TIMEOUT_MS (${CFG_UPSTREAM_TIMEOUT} -> $(( CFG_UPSTREAM_TIMEOUT * 2 )))"
        CFG_UPSTREAM_TIMEOUT=$(( CFG_UPSTREAM_TIMEOUT * 2 ))
        systemctl restart xray 2>/dev/null || true
        need_redeploy=true ;;

      000)
        fail "No response from ${CFG_PLATFORM} (000) — deployment may still be propagating"
        warn "Waiting 15s and retrying..."
        sleep 15
        vercel_code=$(curl -sk --max-time 15 "https://${VERCEL_HOST}${CFG_PUBLIC_PATH}" \
          -o /dev/null -w "%{http_code}" 2>/dev/null || echo "000")
        if [[ "$vercel_code" == "000" ]]; then
          fail "Still no response. Check: https://${VERCEL_HOST}"
        else
          ok "${CFG_PLATFORM} now responding — HTTP $vercel_code"
        fi ;;

      *)
        warn "${CFG_PLATFORM} returned HTTP $vercel_code — may be normal for XHTTP handshake" ;;
    esac

    # ── Auto-redeploy if any fix was applied ──────────────
    if [[ "$need_redeploy" == "true" ]]; then
      echo -e "\n  ${C_MAGENTA}[AutoFix]${C_RESET} Config corrected — redeploying to ${CFG_PLATFORM}..."
      _redeploy_env_fix
      # re-test after redeploy
      sleep 5
      local retest_code
      retest_code=$(curl -sk --max-time 15 \
        "https://${VERCEL_HOST}${CFG_PUBLIC_PATH}" \
        -o /dev/null -w "%{http_code}" 2>/dev/null || echo "000")
      if echo "$retest_code" | grep -qE "^(200|101|404)$"; then
        ok "Post-fix test: HTTP $retest_code — relay is responding"
      else
        warn "Post-fix test: HTTP $retest_code — check ${CFG_PLATFORM} dashboard for build logs"
      fi
    fi
  else
    warn "Relay URL unknown — skipping relay test"
  fi

  # ── Test 3: real end-to-end VLESS test using local xray as client ──
  echo -e "\n  ${C_CYAN}[ Test 3 ] End-to-end VLESS+XHTTP test (real client)${C_RESET}"
  if [[ -z "${VERCEL_HOST:-}" || -z "${INBOUND_UUID:-}" ]]; then
    warn "Missing relay host or UUID — skipping E2E test"
    info "  VERCEL_HOST='${VERCEL_HOST:-<empty>}'  INBOUND_UUID='${INBOUND_UUID:-<empty>}'"
  else
    # Locate the xray binary (must be explicit — PATH can be stripped in screen/sudo)
    local XRAY_BIN
    XRAY_BIN=$(command -v xray 2>/dev/null || echo "")
    [[ -z "$XRAY_BIN" ]] && XRAY_BIN="/usr/local/bin/xray"
    if [[ ! -x "$XRAY_BIN" ]]; then
      warn "xray binary not found at '$XRAY_BIN' — skipping E2E test"
      E2E_STATUS="UNKNOWN"
      E2E_DETAIL="xray binary not found"
    else
    info "E2E vars — relay: ${VERCEL_HOST}  uuid: ${INBOUND_UUID}  path: ${CFG_PUBLIC_PATH}"

    local CLIENT_MODE="auto"
    local TEST_SOCKS_PORT=10809
    local TEST_CFG
    TEST_CFG=$(mktemp --suffix=.json)
    cat > "$TEST_CFG" <<E2ECFG
{
  "log": {"loglevel": "debug"},
  "inbounds": [{
    "tag": "socks-test",
    "port": ${TEST_SOCKS_PORT},
    "listen": "127.0.0.1",
    "protocol": "socks",
    "settings": {"auth": "noauth", "udp": false}
  }],
  "outbounds": [{
    "tag": "vless-out",
    "protocol": "vless",
    "settings": {
      "vnext": [{
        "address": "${VERCEL_HOST}",
        "port": 443,
        "users": [{"id": "${INBOUND_UUID}", "encryption": "none"}]
      }]
    },
    "streamSettings": {
      "network": "xhttp",
      "security": "tls",
      "tlsSettings": {
        "serverName": "${VERCEL_HOST}",
        "alpn": ["h2", "http/1.1"],
        "allowInsecure": false
      },
      "xhttpSettings": {
        "path": "${CFG_PUBLIC_PATH}",
        "host": "${VERCEL_HOST}",
        "mode": "${CLIENT_MODE}"
      }
    }
  }, {
    "protocol": "freedom",
    "tag": "direct"
  }]
}
E2ECFG

    # Free the test port if anything is on it
    local _pid
    _pid=$(lsof -ti:${TEST_SOCKS_PORT} 2>/dev/null || true)
    [[ -n "$_pid" ]] && { info "Killing existing PID ${_pid} on port ${TEST_SOCKS_PORT}"; kill -9 "$_pid" 2>/dev/null || true; sleep 1; }

    # Initialize global E2E status for final summary
    E2E_STATUS="UNKNOWN"
    E2E_DETAIL=""

    info "Starting xray test client (${XRAY_BIN}) on 127.0.0.1:${TEST_SOCKS_PORT}..."
    "$XRAY_BIN" run -c "$TEST_CFG" >/tmp/xray-test-client.log 2>&1 &
    local TEST_PID=$!
    trap "kill ${TEST_PID} 2>/dev/null; sleep 1; kill -9 ${TEST_PID} 2>/dev/null; rm -f '${TEST_CFG}' /tmp/xray-test-client.log 2>/dev/null" RETURN

    # ── Wait up to 12 s for the SOCKS port to actually open ──
    local port_ready=false pw=0
    while [[ $pw -lt 12 ]]; do
      sleep 1; pw=$(( pw + 1 ))
      # Check if process died early
      if ! kill -0 "$TEST_PID" 2>/dev/null; then
        fail "xray test client exited after ${pw}s"
        break
      fi
      # Use ss (preferred) or nc to confirm port is listening
      if ss -tlnp 2>/dev/null | grep -q ":${TEST_SOCKS_PORT} " || \
         nc -z 127.0.0.1 "${TEST_SOCKS_PORT}" 2>/dev/null; then
        port_ready=true
        break
      fi
    done

    if [[ "$port_ready" != "true" ]]; then
      fail "xray test client SOCKS port ${TEST_SOCKS_PORT} never opened (waited ${pw}s)"
      info "Last 15 lines of xray test client log:"
      tail -15 /tmp/xray-test-client.log 2>/dev/null | while read -r l; do echo -e "  ${C_GRAY}  $l${C_RESET}"; done
      E2E_STATUS="FAIL"
      E2E_DETAIL="SOCKS port ${TEST_SOCKS_PORT} did not open (check xray test client log)"
    else
      ok "Test client running (PID $TEST_PID) — SOCKS port ${TEST_SOCKS_PORT} open after ${pw}s"

      # Direct VLESS test. For Netlify we do at most 1 attempt then bail out to
      # the parallel fronted probe — direct test always 429s on the loop path
      # so retrying is just wasted time. For Vercel we retry up to 5×.
      local max_attempts=5
      [[ "${CFG_PLATFORM:-vercel}" == "netlify" ]] && max_attempts=1
      local attempt=0 probe_code="000" probe_time="0"
      local upstream_status="" last_known_upstream=""
      while [[ $attempt -lt $max_attempts ]]; do
        attempt=$(( attempt + 1 ))
        info "VLESS handshake attempt ${attempt}/${max_attempts} → https://www.gstatic.com/generate_204"
        local probe_out
        probe_out=$(curl --socks5-hostname 127.0.0.1:${TEST_SOCKS_PORT} \
          -s -o /dev/null \
          -w "code=%{http_code}|time=%{time_total}" \
          --max-time 15 \
          "https://www.gstatic.com/generate_204" 2>&1 || true)
        probe_code=$(echo "$probe_out" | grep -oP 'code=\K[0-9]+' || echo "000")
        probe_time=$(echo "$probe_out" | grep -oP 'time=\K[0-9.]+' || echo "0")
        if [[ "$probe_code" == "204" || "$probe_code" == "200" ]]; then
          break
        fi

        # Sniff the most recent xray log to figure out *why* the handshake failed
        upstream_status=$(grep -oE "unexpected status [0-9]+" /tmp/xray-test-client.log 2>/dev/null | tail -1 | grep -oE '[0-9]+$' || true)
        [[ -n "$upstream_status" ]] && last_known_upstream="$upstream_status"

        if [[ -n "$upstream_status" ]]; then
          warn "Got HTTP ${probe_code} (CDN responded with ${upstream_status} to XHTTP request)"
        else
          warn "Got HTTP ${probe_code} (no response — likely connection-level block / timeout)"
        fi

        # Wait shorter between attempts (only for Vercel which retries)
        if [[ $attempt -lt $max_attempts ]]; then
          info "Waiting 10s before retry..."
          sleep 10
        fi
      done

      if [[ "$probe_code" == "204" || "$probe_code" == "200" ]]; then
        echo ""
        echo -e "  ${C_GREEN}╔══════════════════════════════════════════════════╗${C_RESET}"
        echo -e "  ${C_GREEN}║  ✔ VLESS+XHTTP WORKS END-TO-END                ║${C_RESET}"
        echo -e "  ${C_GREEN}║    HTTP ${probe_code} in ${probe_time}s — proxy is functional       ║${C_RESET}"
        echo -e "  ${C_GREEN}╚══════════════════════════════════════════════════╝${C_RESET}"
        echo ""

        # ── Latency profiling: 5 pings through the proxy ──
        info "Measuring relay latency (5 samples through VLESS proxy)..."
        local times=()
        local i
        for i in 1 2 3 4 5; do
          local t
          t=$(curl --socks5-hostname 127.0.0.1:${TEST_SOCKS_PORT} \
            -s -o /dev/null \
            -w "%{time_total}" \
            --max-time 15 \
            "https://www.gstatic.com/generate_204" 2>/dev/null || echo "0")
          # Convert to ms (rounded)
          local t_ms
          t_ms=$(awk -v t="$t" 'BEGIN{ printf "%.0f", t*1000 }')
          times+=("$t_ms")
          echo -e "    ${C_GRAY}#$i  → ${t_ms} ms${C_RESET}"
        done

        # Compute min / avg / max
        local min=999999 max=0 sum=0 valid=0
        for t in "${times[@]}"; do
          [[ "$t" == "0" ]] && continue
          (( t < min )) && min=$t
          (( t > max )) && max=$t
          sum=$(( sum + t ))
          valid=$(( valid + 1 ))
        done
        local avg=0
        (( valid > 0 )) && avg=$(( sum / valid ))

        echo ""
        echo -e "  ${C_CYAN}─── Relay Ping (via real VLESS proxy) ───${C_RESET}"
        echo -e "  ${C_WHITE}min :${C_RESET} ${C_GREEN}${min} ms${C_RESET}"
        echo -e "  ${C_WHITE}avg :${C_RESET} ${C_GREEN}${avg} ms${C_RESET}"
        echo -e "  ${C_WHITE}max :${C_RESET} ${C_YELLOW}${max} ms${C_RESET}"
        echo -e "  ${C_GRAY}    (server→relay→upstream→internet round trip)${C_RESET}"
        echo ""

        # Also measure direct relay latency (HTTP HEAD, no proxy)
        info "Measuring direct CDN latency (no proxy, just relay reachability)..."
        local cdn_times=()
        for i in 1 2 3; do
          local ct
          ct=$(curl -s -o /dev/null -w "%{time_total}" --max-time 8 \
            -X HEAD "https://${VERCEL_HOST}/" 2>/dev/null || echo "0")
          local ct_ms
          ct_ms=$(awk -v t="$ct" 'BEGIN{ printf "%.0f", t*1000 }')
          cdn_times+=("$ct_ms")
          echo -e "    ${C_GRAY}#$i  → ${ct_ms} ms${C_RESET}"
        done
        local cdn_sum=0 cdn_valid=0
        for ct in "${cdn_times[@]}"; do
          [[ "$ct" == "0" ]] && continue
          cdn_sum=$(( cdn_sum + ct ))
          cdn_valid=$(( cdn_valid + 1 ))
        done
        local cdn_avg=0
        (( cdn_valid > 0 )) && cdn_avg=$(( cdn_sum / cdn_valid ))
        echo -e "  ${C_CYAN}CDN avg latency:${C_RESET} ${cdn_avg} ms ${C_GRAY}(server → ${VERCEL_HOST})${C_RESET}"
        echo ""

        E2E_STATUS="PASS"
        E2E_DETAIL="HTTP ${probe_code} | min/avg/max: ${min}/${avg}/${max}ms | CDN: ${cdn_avg}ms"
        E2E_PING_MIN=$min
        E2E_PING_AVG=$avg
        E2E_PING_MAX=$max
        E2E_CDN_PING=$cdn_avg
      else
        # ── Netlify 429 fallback: try domain-fronted configs ──────
        # The direct test loops back to the same server IP, which Netlify
        # often rate-limits. Domain fronting (clean IP + clean SNI + Netlify
        # in the Host header) bypasses this. We try a small sample of known
        # clean IP/SNI combinations until one succeeds.
        if [[ "${CFG_PLATFORM:-vercel}" == "netlify" && "$last_known_upstream" == "429" ]]; then
          echo ""
          warn "Direct test got HTTP 429 (Netlify loop-rate-limit on same IP)."
          info "Probing ~1500 IP×SNI combos in parallel (curl-based, max 60s)..."

          # Stop the current test client
          kill "$TEST_PID" 2>/dev/null || true; sleep 1; kill -9 "$TEST_PID" 2>/dev/null || true

          # Full curated lists (35 IPs × 45 SNIs ≈ 1575 combos)
          local FRONT_IPS=(
            50.7.5.83 50.7.5.85 50.7.87.2 50.7.87.3 50.7.87.4 50.7.87.5
            144.76.1.88 216.24.57.1 37.16.18.81 52.250.41.2 76.76.21.21 76.76.21.112
            85.10.207.48 94.130.13.19 94.130.33.41 94.130.50.12 95.216.69.37
            198.202.211.1 198.252.206.1 204.12.196.34 216.150.1.193 65.109.34.234
            94.130.70.160 104.18.25.196 138.201.54.122 142.54.178.211 149.154.167.99
            178.22.122.101 204.79.197.220 213.180.193.56 216.239.38.120
            40.114.177.246 63.141.252.203 64.239.109.193
          )
          local FRONT_SNIS=(
            helm.sh keda.sh rook.io istio.io cilium.io fluxcd.io harbor.io
            calico.org linkerd.io openebs.io tekton.dev longhorn.io
            blog.helm.sh docs.helm.sh crossplane.io kubernetes.io kubebuilder.io
            cert-manager.io letsencrypt.org
            kind.sigs.k8s.io kops.sigs.k8s.io krew.sigs.k8s.io kwok.sigs.k8s.io
            kueue.sigs.k8s.io jobset.sigs.k8s.io kaniko.sigs.k8s.io
            minikube.sigs.k8s.io operatorframework.io container.sigs.k8s.io
            kustomize.sigs.k8s.io argo-cd.readthedocs.io
            cluster-api.sigs.k8s.io descheduler.sigs.k8s.io
            gateway-api.sigs.k8s.io external-dns.sigs.k8s.io
            service-apis.sigs.k8s.io image-builder.sigs.k8s.io
            kubectl.docs.kubernetes.io metrics-server.sigs.k8s.io
            scheduler-plugins.sigs.k8s.io controller-runtime.sigs.k8s.io
            prometheus-operator.sigs.k8s.io node-feature-discovery.sigs.k8s.io
            hierarchical-namespaces.sigs.k8s.io secrets-store-csi-driver.sigs.k8s.io
            security-profiles-operator.sigs.k8s.io
            cluster-proportional-autoscaler.sigs.k8s.io
          )

          # Build combos file and result/stop file
          local combos_file result_file
          combos_file=$(mktemp)
          result_file=$(mktemp)
          : > "$result_file"   # empty
          local total_combos=0
          for fip in "${FRONT_IPS[@]}"; do
            for fsni in "${FRONT_SNIS[@]}"; do
              echo "${fip}|${fsni}" >> "$combos_file"
              total_combos=$(( total_combos + 1 ))
            done
          done
          info "  Total combos: ${total_combos}  |  parallelism: 60  |  per-probe timeout: 2s"

          # Export env so xargs subprocesses can read them
          export NETLIFY_HOST_FOR_PROBE="$VERCEL_HOST"
          export RELAY_PATH_FOR_PROBE="$CFG_PUBLIC_PATH"
          export PROBE_RESULT_FILE="$result_file"

          # Parallel probe — each tests TCP+TLS+Host-header against Netlify endpoint.
          # Counts as success if HTTP response is 2xx/3xx/4xx (NOT 000 / NOT 429).
          # Early-stops globally as soon as any worker writes to result file.
          local probe_start probe_end probe_dur
          probe_start=$(date +%s)
          timeout 60 bash -c '
            while IFS= read -r combo; do
              # Stop early if another worker already found a hit
              [[ -s "$PROBE_RESULT_FILE" ]] && break
              echo "$combo"
            done < "$1"
          ' _ "$combos_file" | \
          xargs -P 60 -I {} -- bash -c '
            [[ -s "$PROBE_RESULT_FILE" ]] && exit 0
            combo="$1"
            ip="${combo%%|*}"
            sni="${combo##*|}"
            out=$(curl -sk --resolve "${sni}:443:${ip}" \
              -o /dev/null -w "%{http_code}|%{time_total}" \
              --max-time 2 \
              --header "Host: ${NETLIFY_HOST_FOR_PROBE}" \
              "https://${sni}${RELAY_PATH_FOR_PROBE}" 2>/dev/null || echo "000|0")
            code="${out%%|*}"
            time_total="${out##*|}"
            # Success = anything that proves Netlify edge received us (not 000, not 429)
            case "$code" in
              200|301|302|404|405|403)
                # Atomically grab the slot (first writer wins)
                if ( set -o noclobber; > "${PROBE_RESULT_FILE}.lock" ) 2>/dev/null; then
                  ms=$(awk -v t="$time_total" "BEGIN{printf \"%.0f\", t*1000}")
                  echo "${ip}|${sni}|${code}|${ms}" > "$PROBE_RESULT_FILE"
                fi
                ;;
            esac
          ' _ {} 2>/dev/null

          probe_end=$(date +%s)
          probe_dur=$(( probe_end - probe_start ))
          rm -f "$combos_file" "${result_file}.lock"

          if [[ -s "$result_file" ]]; then
            local hit; hit=$(cat "$result_file")
            local hit_ip hit_sni hit_code hit_ms
            hit_ip="${hit%%|*}"; hit="${hit#*|}"
            hit_sni="${hit%%|*}"; hit="${hit#*|}"
            hit_code="${hit%%|*}"; hit_ms="${hit##*|}"

            echo ""
            echo -e "  ${C_GREEN}╔══════════════════════════════════════════════════╗${C_RESET}"
            echo -e "  ${C_GREEN}║  ✔ DOMAIN-FRONTED PATH WORKS                    ║${C_RESET}"
            echo -e "  ${C_GREEN}║    Found a working IP/SNI in ${probe_dur}s                  ║${C_RESET}"
            echo -e "  ${C_GREEN}╚══════════════════════════════════════════════════╝${C_RESET}"
            info "  Working combo:  IP=${hit_ip}  SNI=${hit_sni}  ping=${hit_ms}ms (HTTP ${hit_code})"
            info "  Note: real clients can use the main link OR a fronted variant."
            E2E_STATUS="PASS"
            E2E_DETAIL="fronted via ${hit_ip} / ${hit_sni}  (${hit_ms}ms)"
            E2E_PING_MIN="$hit_ms"
            E2E_PING_AVG="$hit_ms"
            E2E_PING_MAX="$hit_ms"
            E2E_CDN_PING="?"
          else
            warn "No working IP/SNI combo found in ${probe_dur}s out of ${total_combos}."
            info "  Direct: 429 (loop rate-limit)  |  Fronted: nothing routed to Netlify from this server"
            info "  Real clients (phone/PC) usually still work — main link is below."
            E2E_STATUS="UNKNOWN"
            E2E_DETAIL="self-test inconclusive — verify with real client"
          fi

          rm -f "$result_file" "$TEST_CFG" /tmp/xray-test-client.log
          trap - RETURN
          return 0
        fi

        echo ""
        echo -e "  ${C_RED}╔══════════════════════════════════════════════════╗${C_RESET}"
        echo -e "  ${C_RED}║  ✘ END-TO-END TEST FAILED                       ║${C_RESET}"
        echo -e "  ${C_RED}║    HTTP ${probe_code:-000} after ${max_attempts} attempts                ║${C_RESET}"
        echo -e "  ${C_RED}╚══════════════════════════════════════════════════╝${C_RESET}"
        echo ""
        E2E_STATUS="FAIL"
        E2E_DETAIL="HTTP ${probe_code:-000} (${max_attempts} attempts)"

        # ── Targeted diagnostics based on what we actually saw ──
        echo -e "  ${C_CYAN}─── Diagnostics ───${C_RESET}"

        # 1. Can the server reach the CDN at all (TCP/443 + TLS)?
        local cdn_reachable
        cdn_reachable=$(curl -sk -o /dev/null -w "%{http_code}" --max-time 8 \
          -X HEAD "https://${VERCEL_HOST}/" 2>/dev/null || echo "000")
        if [[ "$cdn_reachable" == "000" ]]; then
          fail "  • Cannot reach CDN at all (port 443 to ${VERCEL_HOST} blocked from server)"
        else
          ok "  • CDN reachable on 443 (HTTP ${cdn_reachable})"
        fi

        # 2. Is the upstream xray port (server-side) actually open from outside?
        local upstream_reachable
        upstream_reachable=$(curl -sk -o /dev/null -w "%{http_code}" --max-time 8 \
          "https://${CFG_DOMAIN}:${CFG_INBOUND_PORT}${CFG_RELAY_PATH}" 2>/dev/null || echo "000")
        if [[ "$upstream_reachable" == "000" ]]; then
          fail "  • Upstream xray NOT reachable on ${CFG_DOMAIN}:${CFG_INBOUND_PORT} (firewall / port-blocked)"
        else
          ok "  • Upstream xray reachable (HTTP ${upstream_reachable} on ${CFG_INBOUND_PORT})"
        fi

        # 3. Is xray service still alive on the server?
        if systemctl is-active --quiet xray 2>/dev/null; then
          ok "  • xray service is running"
        else
          fail "  • xray service is NOT running on this server"
        fi

        # 4. Decode what we saw at the application layer
        echo ""
        echo -e "  ${C_CYAN}─── Root cause analysis ───${C_RESET}"
        if [[ -n "$last_known_upstream" ]]; then
          case "$last_known_upstream" in
            429)
              warn "  CDN rate-limited the self-test (HTTP 429)"
              info "  ⓘ This is often a FALSE FAILURE. The end-to-end test runs"
              info "    from THIS server, then loops back to itself through the CDN."
              info "    Netlify often rate-limits this loop pattern, even when real"
              info "    clients (phone, desktop, from another network) work perfectly."
              info "  → Try the client config from your phone/PC before assuming it's broken."
              ;;
            500|502|503|504)
              fail "  CDN got upstream error (HTTP ${last_known_upstream}) — relay couldn't reach your server"
              info "  Check: TARGET_DOMAIN env on ${CFG_PLATFORM}, firewall on port ${CFG_INBOUND_PORT}, SSL cert validity"
              ;;
            404)
              fail "  CDN returned 404 — path mismatch between client/server (RELAY_PATH vs PUBLIC_RELAY_PATH)"
              ;;
            403)
              fail "  CDN returned 403 — request rejected (likely WAF or geo-block on relay)"
              ;;
            *)
              fail "  CDN returned HTTP ${last_known_upstream} — see xray log below"
              ;;
          esac
        elif [[ "$cdn_reachable" == "000" ]]; then
          fail "  Network egress to ${VERCEL_HOST}:443 is blocked from this server"
          info "  Fix: check provider firewall / security group / outbound rules"
        elif [[ "$upstream_reachable" == "000" ]]; then
          fail "  Inbound port ${CFG_INBOUND_PORT} is unreachable — CDN can't relay traffic to you"
          info "  Fix: open port ${CFG_INBOUND_PORT} on UFW and provider firewall"
        else
          fail "  Handshake never completed — likely TLS / SNI mismatch or wrong UUID/path"
          info "  Verify: client UUID matches server UUID ${INBOUND_UUID:-?}"
          info "  Verify: client path matches server path ${CFG_RELAY_PATH}"
        fi

        # 5. Always dump xray test client log for offline inspection
        echo ""
        echo -e "  ${C_CYAN}─── xray test client log (last 20 lines) ───${C_RESET}"
        tail -20 /tmp/xray-test-client.log 2>/dev/null | while read -r l; do echo -e "  ${C_GRAY}  $l${C_RESET}"; done
        echo ""
        info "Full xray log saved to: ${LOG_FILE}"
      fi
    fi

    kill "$TEST_PID" 2>/dev/null || true
    sleep 1
    kill -9 "$TEST_PID" 2>/dev/null || true
    rm -f "$TEST_CFG" /tmp/xray-test-client.log
    trap - RETURN
    fi  # end: xray binary found
  fi
  # End of phase5 (Test 4 / xray-knife removed — Test 3 above is the authoritative check)
  return 0
}

# Stub for the rest of the file that still references xray-knife (keep minimal)
_unused_xray_knife_block() {
  if [[ -z "${XRAY_KNIFE_BIN:-}" || ! -x "${XRAY_KNIFE_BIN:-}" ]]; then
    return 0
  fi

  local KNIFE_CFG
  KNIFE_CFG=$(mktemp --suffix=.json)
  cat > "$KNIFE_CFG" <<KNIFECFG
{
  "log": {"loglevel": "warning"},
  "inbounds": [{
    "port": 10809, "listen": "127.0.0.1",
    "protocol": "socks",
    "settings": {"auth": "noauth", "udp": false}
  }],
  "outbounds": [{
    "protocol": "vless",
    "settings": {
      "vnext": [{
        "address": "${VERCEL_HOST:-${CFG_DOMAIN}}",
        "port": 443,
        "users": [{"id": "${INBOUND_UUID:-00000000-0000-0000-0000-000000000000}", "encryption": "none"}]
      }]
    },
    "streamSettings": {
      "network": "xhttp",
      "security": "tls",
      "tlsSettings": {"serverName": "${VERCEL_HOST:-${CFG_DOMAIN}}"},
      "xhttpSettings": {
        "path": "${CFG_PUBLIC_PATH}",
        "host": "${VERCEL_HOST:-${CFG_DOMAIN}}",
        "mode": "auto"
      }
    }
  }]
}
KNIFECFG

  # xray-knife CLI syntax varies by version — try several common forms.
  local knife_out=""
  local knife_ok=false
  local syntaxes=("net http -c" "http -c" "net real -c" "net tcp -c")
  for syn in "${syntaxes[@]}"; do
    knife_out=$("$XRAY_KNIFE_BIN" $syn "$KNIFE_CFG" \
      -d "https://www.gstatic.com/generate_204" -t 15000 2>&1 || true)
    # Real success contains a numeric latency or HTTP status, NOT just the word "ms" in help
    if echo "$knife_out" | grep -qiE '[0-9]+\s*ms\b|delay:\s*[0-9]+|latency:\s*[0-9]+|status:\s*2[0-9]{2}|HTTP/[0-9.]+\s*2[0-9]{2}'; then
      knife_ok=true
      break
    fi
    # If output looks like a syntax/help error, try next variant; otherwise stop.
    if ! echo "$knife_out" | grep -qiE "unknown command|help for|usage:|\bflag\b|requires.*argument"; then
      break
    fi
  done
  rm -f "$KNIFE_CFG"

  if [[ "$knife_ok" == "true" ]]; then
    ok "xray-knife test PASSED ✔"
    echo "$knife_out" | grep -iE 'latency|delay|[0-9]+\s*ms\b|status' | head -3 | while read -r l; do
      echo -e "  ${C_GREEN}  $l${C_RESET}"
    done
  else
    warn "xray-knife test could not run (binary syntax mismatch — non-fatal)"
    info "Proxy is verified by Test 1/2 above. Try the client link to confirm."
  fi
}

# =============================================================
#  PHASE 6 — FINAL SUMMARY
# =============================================================
phase6_summary() {
  local TARGET_DOMAIN_VAL="https://${CFG_DOMAIN}:${CFG_INBOUND_PORT}"
  local VERCEL_HOST
  VERCEL_HOST=$(echo "${VERCEL_URL:-}" | sed 's|https://||' | sed 's|/.*||')
  local ENCODED_PATH
  ENCODED_PATH=$(python3 -c "import urllib.parse; print(urllib.parse.quote('${CFG_PUBLIC_PATH}'))" 2>/dev/null || echo "${CFG_PUBLIC_PATH}")
  local LINK_TAG="XHTTP-${CFG_PLATFORM}"
  # Build the `extra` JSON. Netlify needs obfuscation params; Vercel just gets xPaddingBytes.
  local EXTRA_JSON
  if [[ "${CFG_PLATFORM:-vercel}" == "netlify" ]]; then
    EXTRA_JSON=$(printf '{"xPaddingBytes":"%s","xPaddingObfsMode":true,"xPaddingKey":"%s","xPaddingHeader":"%s","scMaxEachPostBytes":"%s"}' \
      "${XPADDING:-10-50}" "${XPADDING_KEY:-}" "${XPADDING_HEADER:-}" "${SC_MAX_POST_BYTES:-1000000}")
  else
    EXTRA_JSON=$(printf '{"xPaddingBytes":"%s"}' "${XPADDING:-100-1000}")
  fi
  local ENCODED_EXTRA
  ENCODED_EXTRA=$(python3 -c "import urllib.parse,sys; print(urllib.parse.quote(sys.argv[1], safe=''))" "$EXTRA_JSON" 2>/dev/null || echo "$EXTRA_JSON")
  local CLIENT_LINK="vless://${INBOUND_UUID:-UUID}@${VERCEL_HOST}:443?encryption=none&security=tls&sni=${VERCEL_HOST}&fp=chrome&alpn=h2%2Chttp%2F1.1&insecure=0&allowInsecure=0&type=xhttp&host=${VERCEL_HOST}&path=${ENCODED_PATH}&mode=auto&extra=${ENCODED_EXTRA}#${LINK_TAG}"

  echo ""
  echo -e "${C_GREEN}"
  echo "  ╔══════════════════════════════════════════════════════════╗"
  echo "  ║             INSTALLATION COMPLETE  ✔                   ║"
  echo "  ╚══════════════════════════════════════════════════════════╝"
  echo -e "${C_RESET}"
  local SERVER_IP
  SERVER_IP=$(curl -s --max-time 5 ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')
  echo -e "  ${C_WHITE}Platform         :${C_RESET} ${CFG_PLATFORM}"
  echo -e "  ${C_WHITE}Relay URL        :${C_RESET} ${C_CYAN}${VERCEL_URL:-N/A}${C_RESET}"
  echo -e "  ${C_WHITE}Inbound UUID     :${C_RESET} ${C_YELLOW}${INBOUND_UUID:-N/A}${C_RESET}"
  echo -e "  ${C_WHITE}Domain           :${C_RESET} ${CFG_DOMAIN}"
  echo -e "  ${C_WHITE}RELAY_PATH       :${C_RESET} ${CFG_RELAY_PATH}"
  echo -e "  ${C_WHITE}PUBLIC_PATH      :${C_RESET} ${CFG_PUBLIC_PATH}"
  echo -e "  ${C_WHITE}TARGET_DOMAIN    :${C_RESET} ${TARGET_DOMAIN_VAL}"

  # ── Obfuscation params (Netlify only) ──
  if [[ "${CFG_PLATFORM:-vercel}" == "netlify" && -n "${XPADDING_KEY:-}" ]]; then
    echo ""
    echo -e "  ${C_CYAN}── XHTTP Obfuscation (Netlify) ──${C_RESET}"
    echo -e "  ${C_WHITE}xPaddingBytes    :${C_RESET} ${XPADDING:-10-50}"
    echo -e "  ${C_WHITE}xPaddingKey      :${C_RESET} ${C_YELLOW}${XPADDING_KEY:-}${C_RESET}"
    echo -e "  ${C_WHITE}xPaddingHeader   :${C_RESET} ${C_YELLOW}${XPADDING_HEADER:-}${C_RESET}"
    echo -e "  ${C_GRAY}                   (already embedded in the client link below)${C_RESET}"
  fi
  echo ""

  # ── E2E test result (set by phase5_healthcheck) ──
  case "${E2E_STATUS:-UNKNOWN}" in
    PASS)
      echo -e "  ${C_GREEN}E2E Proxy Test   : ✔ PASS${C_RESET}"
      echo -e "  ${C_WHITE}Ping (min/avg/max):${C_RESET} ${C_GREEN}${E2E_PING_MIN:-?}/${E2E_PING_AVG:-?}/${E2E_PING_MAX:-?} ms${C_RESET} ${C_GRAY}(through VLESS)${C_RESET}"
      echo -e "  ${C_WHITE}CDN Ping         :${C_RESET} ${C_CYAN}${E2E_CDN_PING:-?} ms${C_RESET} ${C_GRAY}(direct to relay)${C_RESET}"
      # Quality assessment
      if (( ${E2E_PING_AVG:-9999} < 300 )); then
        echo -e "  ${C_GREEN}Quality          : Excellent${C_RESET}"
      elif (( ${E2E_PING_AVG:-9999} < 600 )); then
        echo -e "  ${C_YELLOW}Quality          : Good${C_RESET}"
      elif (( ${E2E_PING_AVG:-9999} < 1200 )); then
        echo -e "  ${C_YELLOW}Quality          : Acceptable (high latency)${C_RESET}"
      else
        echo -e "  ${C_RED}Quality          : Poor (very high latency)${C_RESET}"
      fi
      echo -e "  ${C_GREEN}                   Your client config IS verified to work.${C_RESET}"
      ;;
    FAIL)
      echo -e "  ${C_RED}E2E Proxy Test   : ✘ FAIL${C_RESET} ${C_GRAY}(${E2E_DETAIL})${C_RESET}"
      echo -e "  ${C_RED}                   The client config may NOT work — check log: ${LOG_FILE}${C_RESET}"
      ;;
    *)
      echo -e "  ${C_YELLOW}E2E Proxy Test   : ⚠ NOT RUN${C_RESET}"
      ;;
  esac
  echo ""

  echo -e "  ${C_CYAN}── Client Config (copy into your v2ray/xray client) ──${C_RESET}"
  echo ""
  echo -e "  ${C_YELLOW}${CLIENT_LINK}${C_RESET}"
  echo ""

  echo -e "  ${C_CYAN}── Management Panel ──${C_RESET}"
  echo -e "  ${C_WHITE}Type ${C_YELLOW}xhttp${C_WHITE} anytime to open the panel${C_RESET}"
  echo -e "  ${C_GRAY}    (view config, restart xray, renew SSL, view logs, uninstall, …)${C_RESET}"
  echo ""

  echo -e "  ${C_GRAY}Full install log saved to: ${LOG_FILE}${C_RESET}"
  echo -e "${C_GREEN}  ══════════════════════════════════════════════════════════${C_RESET}"
  echo ""
}

# =============================================================
#  PHASE 7 — INSTALL MANAGEMENT PANEL ( `xhttp` CLI )
# =============================================================
phase7_install_panel() {
  step "PHASE 7 — Installing management panel ( type 'xhttp' to open )"

  # ── 1. Persist install state ─────────────────────────────────
  local STATE_DIR="/etc/xhttp-installer"
  local STATE_FILE="${STATE_DIR}/info.env"
  mkdir -p "$STATE_DIR"
  chmod 700 "$STATE_DIR"

  # Build the client link (same as summary)
  local VERCEL_HOST ENCODED_PATH EXTRA_JSON ENCODED_EXTRA CLIENT_LINK
  VERCEL_HOST=$(echo "${VERCEL_URL:-}" | sed 's|https://||; s|/.*||')
  ENCODED_PATH=$(python3 -c "import urllib.parse; print(urllib.parse.quote('${CFG_PUBLIC_PATH}'))" 2>/dev/null || echo "${CFG_PUBLIC_PATH}")
  if [[ "${CFG_PLATFORM:-vercel}" == "netlify" ]]; then
    EXTRA_JSON=$(printf '{"xPaddingBytes":"%s","xPaddingObfsMode":true,"xPaddingKey":"%s","xPaddingHeader":"%s","scMaxEachPostBytes":"%s"}' \
      "${XPADDING:-10-50}" "${XPADDING_KEY:-}" "${XPADDING_HEADER:-}" "${SC_MAX_POST_BYTES:-1000000}")
  else
    EXTRA_JSON=$(printf '{"xPaddingBytes":"%s"}' "${XPADDING:-100-1000}")
  fi
  ENCODED_EXTRA=$(python3 -c "import urllib.parse,sys; print(urllib.parse.quote(sys.argv[1], safe=''))" "$EXTRA_JSON" 2>/dev/null || echo "$EXTRA_JSON")
  CLIENT_LINK="vless://${INBOUND_UUID}@${VERCEL_HOST}:443?encryption=none&security=tls&sni=${VERCEL_HOST}&fp=chrome&alpn=h2%2Chttp%2F1.1&insecure=0&allowInsecure=0&type=xhttp&host=${VERCEL_HOST}&path=${ENCODED_PATH}&mode=auto&extra=${ENCODED_EXTRA}#XHTTP-${CFG_PLATFORM}"

  cat > "$STATE_FILE" <<STATE
# XHTTP Installer — persisted state ( do not edit by hand )
INSTALL_DATE="$(date -Iseconds)"
CFG_PLATFORM="${CFG_PLATFORM}"
CFG_DOMAIN="${CFG_DOMAIN}"
CFG_EMAIL="${CFG_EMAIL}"
CFG_INBOUND_PORT="${CFG_INBOUND_PORT}"
CFG_RELAY_PATH="${CFG_RELAY_PATH}"
CFG_PUBLIC_PATH="${CFG_PUBLIC_PATH}"
INBOUND_UUID="${INBOUND_UUID}"
VERCEL_URL="${VERCEL_URL:-}"
VERCEL_HOST="${VERCEL_HOST}"
SSL_CERT="${SSL_CERT:-}"
SSL_KEY="${SSL_KEY:-}"
XPADDING="${XPADDING:-}"
XPADDING_KEY="${XPADDING_KEY:-}"
XPADDING_HEADER="${XPADDING_HEADER:-}"
SC_MAX_POST_BYTES="${SC_MAX_POST_BYTES:-}"
CLIENT_LINK="${CLIENT_LINK}"
HYBRID_SUB_URL="${HYBRID_SUB_URL:-}"
HYBRID_CONFIG_COUNT="${HYBRID_CONFIG_COUNT:-0}"
E2E_STATUS="${E2E_STATUS:-UNKNOWN}"
E2E_PING_AVG="${E2E_PING_AVG:-0}"
LOG_FILE="${LOG_FILE}"
STATE

  chmod 600 "$STATE_FILE"
  ok "State saved → $STATE_FILE"

  # ── 2. Write the panel script ────────────────────────────────
  cat > /usr/local/bin/xhttp <<'PANEL'
#!/usr/bin/env bash
# XHTTP Installer — management panel
set -u

STATE_FILE="/etc/xhttp-installer/info.env"
[[ ! -f "$STATE_FILE" ]] && { echo "XHTTP Installer not found. Run the installer first."; exit 1; }
# shellcheck source=/dev/null
source "$STATE_FILE"

C_RESET="\033[0m"; C_CYAN="\033[1;36m"; C_YELLOW="\033[1;33m"; C_GREEN="\033[1;32m"
C_RED="\033[1;31m"; C_GRAY="\033[0;90m"; C_WHITE="\033[1;37m"; C_MAGENTA="\033[1;35m"

_banner() {
  clear
  echo ""
  echo -e "   ${C_CYAN}╔══════════════════════════════════════════╗${C_RESET}"
  echo -e "   ${C_CYAN}║${C_WHITE}        XHTTP Installer — Panel         ${C_CYAN}║${C_RESET}"
  echo -e "   ${C_CYAN}║${C_GRAY}        avaco_cloud · t.me/avaco_cloud   ${C_CYAN}║${C_RESET}"
  echo -e "   ${C_CYAN}╚══════════════════════════════════════════╝${C_RESET}"
  echo ""
}

_status_line() {
  # Compact one-line status (running/stopped + port + cert expiry)
  local xray_state="${C_RED}stopped${C_RESET}"
  systemctl is-active --quiet xray 2>/dev/null && xray_state="${C_GREEN}running${C_RESET}"

  local port_state="${C_RED}closed${C_RESET}"
  ss -tlnp 2>/dev/null | grep -q ":${CFG_INBOUND_PORT} " && port_state="${C_GREEN}listening${C_RESET}"

  local cert_expiry="?"
  if [[ -n "${SSL_CERT:-}" && -f "${SSL_CERT}" ]]; then
    cert_expiry=$(openssl x509 -in "$SSL_CERT" -noout -enddate 2>/dev/null | cut -d= -f2 || echo "?")
  fi

  echo -e "  ${C_WHITE}xray         :${C_RESET} ${xray_state}"
  echo -e "  ${C_WHITE}port ${CFG_INBOUND_PORT}    :${C_RESET} ${port_state}"
  echo -e "  ${C_WHITE}domain       :${C_RESET} ${CFG_DOMAIN}"
  echo -e "  ${C_WHITE}platform     :${C_RESET} ${CFG_PLATFORM}"
  echo -e "  ${C_WHITE}relay        :${C_RESET} ${VERCEL_URL:-N/A}"
  echo -e "  ${C_WHITE}cert expiry  :${C_RESET} ${cert_expiry}"
  if [[ "${E2E_STATUS:-}" == "PASS" ]]; then
    echo -e "  ${C_WHITE}E2E test     :${C_RESET} ${C_GREEN}PASS${C_RESET} ${C_GRAY}(${E2E_PING_AVG}ms avg)${C_RESET}"
  elif [[ "${E2E_STATUS:-}" == "FAIL" ]]; then
    echo -e "  ${C_WHITE}E2E test     :${C_RESET} ${C_RED}FAIL${C_RESET}"
  fi
}

_show_config() {
  _banner
  echo -e "  ${C_CYAN}── Client config ──${C_RESET}"
  echo ""
  echo -e "  ${C_YELLOW}${CLIENT_LINK}${C_RESET}"
  echo ""
  echo -e "  ${C_WHITE}UUID           :${C_RESET} ${C_YELLOW}${INBOUND_UUID}${C_RESET}"
  echo -e "  ${C_WHITE}Domain         :${C_RESET} ${CFG_DOMAIN}"
  echo -e "  ${C_WHITE}Port           :${C_RESET} ${CFG_INBOUND_PORT}"
  echo -e "  ${C_WHITE}RELAY_PATH     :${C_RESET} ${CFG_RELAY_PATH}"
  echo -e "  ${C_WHITE}PUBLIC_PATH    :${C_RESET} ${CFG_PUBLIC_PATH}"
  echo -e "  ${C_WHITE}Relay host     :${C_RESET} ${VERCEL_HOST}"
  if [[ "${CFG_PLATFORM:-}" == "netlify" && -n "${XPADDING_KEY:-}" ]]; then
    echo ""
    echo -e "  ${C_CYAN}── Obfuscation params (Netlify) ──${C_RESET}"
    echo -e "  ${C_WHITE}xPaddingBytes  :${C_RESET} ${XPADDING:-10-50}"
    echo -e "  ${C_WHITE}xPaddingKey    :${C_RESET} ${C_YELLOW}${XPADDING_KEY}${C_RESET}"
    echo -e "  ${C_WHITE}xPaddingHeader :${C_RESET} ${C_YELLOW}${XPADDING_HEADER}${C_RESET}"
    echo -e "  ${C_GRAY}                   (already in the link above)${C_RESET}"
  fi
  echo ""
  read -rp "  Press Enter to return..." _
}

_show_status() {
  _banner
  echo -e "  ${C_CYAN}── System status ──${C_RESET}"
  echo ""
  _status_line
  echo ""

  echo -e "  ${C_CYAN}── xray service ──${C_RESET}"
  systemctl status xray --no-pager -n 5 2>/dev/null | head -12 | \
    while IFS= read -r l; do echo "   $l"; done
  echo ""
  read -rp "  Press Enter to return..." _
}

_restart_xray() {
  _banner
  echo -e "  ${C_CYAN}── Restarting xray ──${C_RESET}"
  systemctl restart xray
  sleep 2
  if systemctl is-active --quiet xray; then
    echo -e "  ${C_GREEN}✔ xray restarted successfully${C_RESET}"
  else
    echo -e "  ${C_RED}✘ xray failed to start${C_RESET}"
    journalctl -u xray -n 10 --no-pager | sed 's/^/   /'
  fi
  echo ""
  read -rp "  Press Enter to return..." _
}

_view_logs() {
  _banner
  echo -e "  ${C_CYAN}── Log options ──${C_RESET}"
  echo "    1) xray error log (last 30 lines)"
  echo "    2) xray access log (last 30 lines)"
  echo "    3) xray systemd journal (last 50 lines)"
  echo "    4) install log"
  echo "    0) back"
  echo ""
  read -rp "  Choose: " ch
  case "$ch" in
    1) tail -n 30 /var/log/xray/error.log 2>/dev/null || echo "no log"; read -rp "Enter..." _;;
    2) tail -n 30 /var/log/xray/access.log 2>/dev/null || echo "no log"; read -rp "Enter..." _;;
    3) journalctl -u xray -n 50 --no-pager; read -rp "Enter..." _;;
    4) tail -n 100 "${LOG_FILE:-/tmp/xhttp-install.log}" 2>/dev/null || echo "no log"; read -rp "Enter..." _;;
  esac
}

_renew_ssl() {
  _banner
  echo -e "  ${C_CYAN}── Renewing SSL certificate ──${C_RESET}"
  local ACME="${HOME}/.acme.sh/acme.sh"
  if [[ ! -x "$ACME" ]]; then
    echo -e "  ${C_RED}acme.sh not found at $ACME${C_RESET}"
    read -rp "Enter..." _; return
  fi
  systemctl stop xray 2>/dev/null
  sleep 2
  "$ACME" --renew -d "$CFG_DOMAIN" --force --ecc --server letsencrypt 2>&1 | tail -10
  systemctl start xray 2>/dev/null
  echo ""
  echo -e "  ${C_GREEN}Done. New expiry:${C_RESET}"
  openssl x509 -in "$SSL_CERT" -noout -enddate 2>/dev/null
  echo ""
  read -rp "Enter..." _
}

_update_script() {
  _banner
  echo -e "  ${C_CYAN}── Update / Re-deploy ──${C_RESET}"
  echo ""
  echo -e "  ${C_GRAY}This pulls the latest installer, re-runs the deploy phase,${C_RESET}"
  echo -e "  ${C_GRAY}and keeps your existing SSL cert (acme.sh auto-skips if still valid).${C_RESET}"
  echo -e "  ${C_GRAY}Your UUID, domain, and config stay the same.${C_RESET}"
  echo ""
  read -rp "  Continue? [y/N]: " yn
  case "${yn,,}" in y|yes) ;; *) return ;; esac

  local TARGET_DIR="/root/XHTTP-Installer"
  if [[ -d "$TARGET_DIR/.git" ]]; then
    echo -e "  ${C_CYAN}Pulling latest from GitHub...${C_RESET}"
    git -C "$TARGET_DIR" fetch --depth=1 origin main 2>&1 | tail -5
    git -C "$TARGET_DIR" reset --hard origin/main 2>&1 | tail -3
  else
    echo -e "  ${C_YELLOW}No existing checkout — cloning fresh...${C_RESET}"
    git clone --depth=1 --branch main \
      "https://github.com/mohammad8422baghir/portfolio-app" "$TARGET_DIR" 2>&1 | tail -5
  fi

  echo ""
  echo -e "  ${C_CYAN}Running updated installer (will re-use existing SSL)...${C_RESET}"
  sleep 1
  cd "$TARGET_DIR"
  chmod +x Deploy-Ubuntu.sh
  exec env XHTTP_NO_SCREEN=1 bash Deploy-Ubuntu.sh
}


# ── Main menu loop ──
while true; do
  _banner
  _status_line
  echo ""
  echo -e "  ${C_CYAN}── Menu ──${C_RESET}"
  echo -e "    ${C_YELLOW}1${C_RESET}) Show client config"
  echo -e "    ${C_YELLOW}2${C_RESET}) Show detailed status"
  echo -e "    ${C_YELLOW}3${C_RESET}) Restart xray"
  echo -e "    ${C_YELLOW}4${C_RESET}) View logs"
  echo -e "    ${C_YELLOW}5${C_RESET}) Renew SSL certificate"
  echo -e "    ${C_YELLOW}6${C_RESET}) ${C_CYAN}Update / Re-deploy${C_RESET} ${C_GRAY}(keeps existing SSL)${C_RESET}"
  echo -e "    ${C_YELLOW}7${C_RESET}) ${C_RED}Uninstall${C_RESET}"
  echo -e "    ${C_YELLOW}0${C_RESET}) Exit"
  echo ""
  read -rp "  Choose [0-7]: " choice
  case "$choice" in
    1) _show_config ;;
    2) _show_status ;;
    3) _restart_xray ;;
    4) _view_logs ;;
    5) _renew_ssl ;;
    6) _update_script ;;
    7) _uninstall ;;
    0) clear; exit 0 ;;
    *) ;;
  esac
done
PANEL

  chmod +x /usr/local/bin/xhttp
  ok "Panel installed → /usr/local/bin/xhttp"
  info "Open anytime with: ${C_YELLOW}xhttp${C_RESET}"
}

# =============================================================
#  AUTO-WRAP IN SCREEN (so SSH disconnect won't kill the install)
# =============================================================
ensure_screen_session() {
  # If already inside screen ($STY) or tmux ($TMUX), do nothing.
  if [[ -n "${STY:-}" ]]; then
    info "Already inside screen session: $STY"
    return 0
  fi
  if [[ -n "${TMUX:-}" ]]; then
    info "Already inside tmux session — proceeding"
    return 0
  fi
  # Skip if user explicitly opts out
  if [[ "${XHTTP_NO_SCREEN:-0}" == "1" ]]; then
    info "XHTTP_NO_SCREEN=1 set — skipping screen wrapper"
    return 0
  fi

  echo ""
  echo -e "  ${C_YELLOW}⚠ You are NOT inside screen/tmux.${C_RESET}"
  echo -e "  ${C_GRAY}If your SSH disconnects, the installation will die mid-way.${C_RESET}"
  echo -e "  ${C_GRAY}Recommended: run inside screen so you can reattach with: ${C_WHITE}screen -r xhttp${C_RESET}"
  echo ""
  read -rp "$(echo -e "  ${C_WHITE}Auto-launch inside screen? [Y/n]${C_RESET}: ")" yn
  case "${yn,,}" in
    n|no)
      warn "Continuing WITHOUT screen — be careful with SSH stability"
      return 0 ;;
  esac

  # Install screen if missing
  if ! command -v screen &>/dev/null; then
    info "Installing screen..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq screen 2>/dev/null || {
      fail "Could not install screen — continuing without it"
      return 0
    }
  fi

  # Handle existing session if present
  if screen -ls 2>/dev/null | grep -q "\.xhttp\b"; then
    warn "Existing screen session 'xhttp' found."
    echo -e "  ${C_GRAY}1) Reattach to it     (continue what was running)${C_RESET}"
    echo -e "  ${C_GRAY}2) Kill it & start fresh${C_RESET}"
    echo -e "  ${C_GRAY}3) Cancel${C_RESET}"
    local sc_choice
    read -rp "$(echo -e "  ${C_WHITE}Choose [1/2/3]${C_RESET}: ")" sc_choice
    case "$sc_choice" in
      1)
        ok "Reattaching..."
        exec screen -r xhttp ;;
      2)
        info "Killing old session..."
        screen -S xhttp -X quit 2>/dev/null || true
        sleep 1
        ;;
      *)
        info "Cancelled."
        exit 0 ;;
    esac
  fi

  # Re-launch self inside screen (UTF-8 enabled with -U)
  local script_path
  script_path="$(realpath "$0" 2>/dev/null || echo "$0")"
  ok "Launching inside screen session 'xhttp'..."
  echo -e "  ${C_GRAY}Detach anytime with Ctrl+A then D${C_RESET}"
  echo -e "  ${C_GRAY}If SSH drops, reconnect and run: ${C_WHITE}screen -r xhttp${C_RESET}"
  sleep 2
  # IMPORTANT: pass XHTTP_NO_SCREEN through sudo (sudo strips env by default).
  # `sudo VAR=value cmd` passes VAR into the command's environment.
  exec screen -U -S xhttp bash -c "sudo XHTTP_NO_SCREEN=1 bash '$script_path'; echo; echo 'Press Enter to close screen...'; read"
}

# =============================================================
#  ENTRYPOINT
# =============================================================
main() {
  print_banner
  ensure_screen_session
  print_banner
  echo -e "  ${C_MAGENTA}Important:${C_RESET} Make sure your domain DNS A-record points to this server IP before continuing."
  echo -e "  ${C_GRAY}Tip: Press Ctrl+C at any time to abort.${C_RESET}"
  echo ""

  echo -e "  ${C_CYAN}[ Deployment Platform ]${C_RESET}"
  echo -e "  ${C_WHITE}Choose relay platform:${C_RESET}"
  echo -e "    ${C_YELLOW}1${C_RESET}) Vercel"
  echo -e "    ${C_YELLOW}2${C_RESET}) Netlify"
  while true; do
    read -rp "$(echo -e "  ${C_WHITE}Enter choice [1/2]${C_RESET}: ")" plat_choice
    case "$plat_choice" in
      1) CFG_PLATFORM="vercel";  break ;;
      2) CFG_PLATFORM="netlify"; break ;;
      *) fail "Enter 1 for Vercel or 2 for Netlify" ;;
    esac
  done
  ok "Platform: ${CFG_PLATFORM}"
  echo ""

  read -rp "$(echo -e "  ${C_WHITE}Press Enter to start installation...${C_RESET}")"

  phase1_preflight
  phase2_install_all
  phase3_collect_input
  autofix_diagnose "FIREWALL"
  autofix_and_retry "SSL"    phase4a_ssl
  autofix_and_retry "XRAYSSL" phase4b_configure_xray
  autofix_and_retry "${CFG_PLATFORM:-vercel}" phase4c_deploy
  phase5_healthcheck
  phase7_install_panel
  phase6_summary
}

main "$@"
